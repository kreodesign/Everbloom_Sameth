<?php

class Router {
    private $rutas = [];
    private $conexion;

    public function definir($rutas, $pdo) {
        $this->rutas = $rutas;
        $this->conexion = $pdo;
    }

        public function ejecutar() {
        // 1. Obtener y limpiar la URL (ej: "producto/5")
        $url = isset($_GET['url']) ? rtrim($_GET['url'], '/') : '';
        
        // Separamos por "/" para obtener las partes
        $partes = explode('/', $url);
        
        // La "ruta base" es la primera palabra (ej: "producto")
        $rutaBase = ($partes[0] === '') ? '' : $partes[0];

        // 2. Verificar si esa ruta base existe en nuestro mapa (index.php)
        if (array_key_exists($rutaBase, $this->rutas)) {
            $config = $this->rutas[$rutaBase];
            $pdo = $this->conexion;

            // 3. Captura del ID (Si existe la segunda parte de la URL)
            if (isset($partes[1])) {
                $_GET['id'] = $partes[1];
            }

            // --- LÓGICA DE PROTECCIÓN (AUTH) ---
            if (isset($config['auth']) && $config['auth'] === true) {
                if (session_status() === PHP_SESSION_NONE) session_start();
                if (!isset($_SESSION['login'])) {
                    header('Location: /login'); // Asegúrate de que la ruta sea correcta
                    exit;
                }
            }

            // 4. EJECUCIÓN: Controlador o Vista
            if (isset($config['controller'])) {
                $controllerName = $config['controller'];
                $method = $config['method'];

                require_once __DIR__ . "/controllers/$controllerName.php";
                $instancia = new $controllerName();
                return $instancia->$method();
            } 
            
            if (isset($config['view'])) {
                $vista = 'views/' . $config['view'];
                if (file_exists($vista)) {
                    return require_once $vista;
                }
            }
        }

        // 5. Si no hay coincidencia, Error 404
        http_response_code(404);
        if (file_exists('views/404.php')) {
            include 'views/404.php';
        } else {
            echo "404 - Página no encontrada: " . htmlspecialchars($url);
        }
    }
}