<?php

/**
 * Genera una estructura de árbol recursiva de un directorio.
 * * @param string $dir Ruta del directorio a escanear.
 * @param string $prefix Prefijo visual para las líneas actuales.
 * @param array $ignore Nombres de archivos/carpetas a ignorar.
 * @return string Estructura en formato texto.
 */
function generateTree($dir, $prefix = '', $ignore = ['.git', 'vendor', 'node_modules', 'generate_tree.php']) {
    $tree = '';
    
    // Escanear directorio actual
    $files = scandir($dir);
    
    // Filtrar archivos no deseados (. y .. y los ignorados)
    $filteredFiles = [];
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && !in_array($file, $ignore)) {
            $filteredFiles[] = $file;
        }
    }
    
    $count = count($filteredFiles);
    $i = 0;
    
    foreach ($filteredFiles as $file) {
        $isLast = (++$i === $count);
        $path = $dir . DIRECTORY_SEPARATOR . $file;
        
        // Seleccionar los caracteres de ramificación correctos
        $marker = $isLast ? '└── ' : '├── ';
        $tree .= $prefix . $marker . $file . PHP_EOL;
        
        // Si es un directorio, llamar a la función recursivamente
        if (is_dir($path)) {
            $extensionPrefix = $isLast ? '    ' : '│   ';
            $tree .= generateTree($path, $prefix . $extensionPrefix, $ignore);
        }
    }
    
    return $tree;
}

// Configuración de rutas
$rootDir = __DIR__;
$outputFile = $rootDir . DIRECTORY_SEPARATOR . 'readme.txt';

// Generar el contenido
$treeOutput = "Estructura del Proyecto:\n";
$treeOutput .= "========================\n\n";
$treeOutput .= basename($rootDir) . "\n";
$treeOutput .= generateTree($rootDir);

// Guardar en readme.txt
if (file_put_contents($outputFile, $treeOutput) !== false) {
    echo "¡Éxito! Archivo readme.txt generado correctamente en:\n" . $outputFile . "\n";
} else {
    echo "Error: No se pudo escribir el archivo. Verifica los permisos de escritura.\n";
}

?>