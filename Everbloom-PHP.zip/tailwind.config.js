/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class', // Esto es clave para activar el modo oscuro basado en clases
  content: ["./**/*.php"],
  theme: {
    extend: {
      colors: {
        // Esta estructura debe ser idéntica a la que tenías en el script
        brand: {
          light: '#fdf4ff',
          primary: '#d946ef',
          dark: '#701a75',
          accent: '#facc15',
        },
        'satin-rose': '#f06292', // Mantén este si lo usas en otros lados
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'serif'],
        sans: ['"Lato"', 'sans-serif']
      },
      // Añadimos la animación para el degradado en movimiento
      keyframes: {
        shimmer: {
          '0%': { 'background-position': '0% 50%' },
          '50%': { 'background-position': '100% 50%' },
          '100%': { 'background-position': '0% 50%' },
        },
      },
      animation: {
        'shimmer-text': 'shimmer 3s ease infinite',
      },
    },
  },
  plugins: [],
}