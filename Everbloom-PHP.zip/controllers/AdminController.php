<?php
/**
 * Everbloom Admin - Controlador de Lógica
 * Ubicación: /controllers/AdminController.php
 */

class AdminController {
    
    /**
     * Procesa, convierte a WebP y guarda imágenes en la carpeta del producto.
     */
    private function procesarImagenWebP($fileTmp, $idProducto, $nombreArchivo = "1.webp") {
        $baseDir = $_SERVER['DOCUMENT_ROOT'] . "/public/img/productos/";
        $folderPath = $baseDir . $idProducto . "/";
        
        if (!is_dir($folderPath)) {
            mkdir($folderPath, 0777, true);
        }

        $rutaFinal = $folderPath . $nombreArchivo;
        $info = getimagesize($fileTmp);
        if (!$info) return false;

        // Crear recurso de imagen según el tipo original
        switch ($info['mime']) {
            case 'image/jpeg': $img = imagecreatefromjpeg($fileTmp); break;
            case 'image/png':  $img = imagecreatefrompng($fileTmp);  break;
            case 'image/webp': $img = imagecreatefromwebp($fileTmp); break;
            default: return false;
        }

        // Guardar como WebP con calidad 80 (balance profesional peso/calidad)
        imagewebp($img, $rutaFinal, 80);
        imagedestroy($img);
        return $nombreArchivo;
    }

    private function eliminarCarpetaProducto($idProducto) {
        $dir = $_SERVER['DOCUMENT_ROOT'] . "/public/img/productos/" . $idProducto;
        if (!is_dir($dir)) return;
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) { unlink("$dir/$file"); }
        rmdir($dir);
    }

    public function index() {
        global $pdo; // Usamos la conexión definida en config/db.php
        
        // Detectar si la petición es AJAX (para respuestas JSON rápidas)
        $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? '';

            try {
                // ACCIÓN: AÑADIR PRODUCTO
                if ($action === 'add_product') {
                    $stmt = $pdo->prepare("INSERT INTO productos (nombre, descripcion, precio_base, categoria_id, imagen_principal) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$_POST['nombre'], $_POST['description'], $_POST['precio_base'], $_POST['categoria_id'], '1.webp']);
                    $idNuevo = $pdo->lastInsertId();

                    if (!empty($_FILES['imagen_archivo']['tmp_name'])) {
                        $this->procesarImagenWebP($_FILES['imagen_archivo']['tmp_name'], $idNuevo, "1.webp");
                    }

                    // Galería adicional
                    if (!empty($_FILES['galeria']['name'][0])) {
                        foreach ($_FILES['galeria']['tmp_name'] as $key => $tmpName) {
                            if ($key >= 5) break; 
                            $nombreGal = "gal_" . time() . "_" . $key . ".webp";
                            $this->procesarImagenWebP($tmpName, $idNuevo, $nombreGal);
                            $pdo->prepare("INSERT INTO producto_imagenes (producto_id, ruta) VALUES (?, ?)")->execute([$idNuevo, $nombreGal]);
                        }
                    }

                    // RESPUESTA LIMPIA PARA AJAX
                    if ($isAjax) {
                        ob_clean(); // Elimina cualquier eco previo o espacio en blanco
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode(['status' => 'success', 'message' => 'Producto creado con éxito']);
                        exit; // Corta la ejecución para que no se pegue el HTML
                    }
                }

                // ACCIÓN: ELIMINAR PRODUCTO
                if ($action === 'delete_product') {
                    $id = $_POST['id'];
                    $this->eliminarCarpetaProducto($id);
                    $pdo->prepare("DELETE FROM productos WHERE id = ?")->execute([$id]);
                    
                    if ($isAjax) {
                        ob_clean();
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode(['status' => 'success', 'message' => 'Producto eliminado']);
                        exit;
                    }
                }

                // ACCIÓN: EDITAR PRODUCTO
                if ($action === 'edit_product') {
                    $id = $_POST['id'];
                    $stmt = $pdo->prepare("UPDATE productos SET nombre = ?, precio_base = ?, categoria_id = ?, descripcion = ? WHERE id = ?");
                    $stmt->execute([$_POST['nombre'], $_POST['precio_base'], $_POST['categoria_id'], $_POST['description'], $id]);

                    // Si subió una nueva imagen, la reemplazamos
                    if (!empty($_FILES['imagen_archivo']['tmp_name'])) {
                        $this->procesarImagenWebP($_FILES['imagen_archivo']['tmp_name'], $id, "1.webp");
                    }

                    if ($isAjax) {
                        ob_clean();
                        header('Content-Type: application/json');
                        echo json_encode(['status' => 'success']);
                        exit;
                    }
                }

            } catch (Exception $e) {
                if ($isAjax) {
                    ob_clean();
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
                    exit;
                }
            }
        }

        // CARGA DE DATOS PARA LA VISTA
        $productos = $pdo->query("SELECT p.*, c.nombre as cat_nombre FROM productos p LEFT JOIN categorias c ON p.categoria_id = c.id ORDER BY p.id DESC")->fetchAll(PDO::FETCH_OBJ);
        $categorias = $pdo->query("SELECT * FROM categorias ORDER BY nombre ASC")->fetchAll(PDO::FETCH_OBJ);
        
        // Estadísticas rápidas para los counters del panel
        $stats = [
            'total_productos' => count($productos),
            'hoy' => 0, // Aquí podrías contar mensajes nuevos
            'pedidos' => 0
        ];

        // Cargamos el Dashboard (la vista)
        include $_SERVER['DOCUMENT_ROOT'] . '/admin/dashboard.php';
    }
}