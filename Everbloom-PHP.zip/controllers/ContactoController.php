<?php
// controllers/ContactoController.php
require_once __DIR__ . '/../models/Mensaje.php';

class ContactoController {
    
    public function enviar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 1. Capturar y limpiar datos
            $nombre = htmlspecialchars($_POST['nombre'] ?? '', ENT_QUOTES, 'UTF-8');
            $telefono = htmlspecialchars($_POST['telefono'] ?? '', ENT_QUOTES, 'UTF-8');
            $motivo = htmlspecialchars($_POST['motivo'] ?? '', ENT_QUOTES, 'UTF-8');
            $mensaje = htmlspecialchars($_POST['mensaje'] ?? '', ENT_QUOTES, 'UTF-8');
            $fecha = date('Y-m-d H:i:s');

            // 2. Validación básica
            if (empty($nombre) || empty($mensaje) || empty($telefono)) {
                header('Location: contacto?error=campos_vacios');
                exit;
            }

            // 3. Guardar en la base de datos
            try {
                // Accedemos a la conexión global creada en db.php
                global $pdo; 
                
                $query = "INSERT INTO mensajes_contacto (nombre, telefono, motivo, mensaje, fecha) 
                          VALUES (:nombre, :telefono, :motivo, :mensaje, :fecha)";
                
                $stmt = $pdo->prepare($query);
                $resultado = $stmt->execute([
                    ':nombre'   => $nombre,
                    ':telefono' => $telefono,
                    ':motivo'   => $motivo,
                    ':mensaje'  => $mensaje,
                    ':fecha'    => $fecha
                ]);

                if ($resultado) {
                    header('Location: contacto?exito=enviado');
                    exit;
                }
            } catch (PDOException $e) {
                // Si hay error, puedes verlo con: die($e->getMessage());
                header('Location: contacto?error=db_error');
                exit;
            }
        }
    }
}