<?php
// controllers/AuthController.php

class AuthController {

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            global $pdo;
            
            // 1. Limpiar y validar entradas
            // trim() es vital para evitar espacios accidentales al copiar/pegar contraseñas
            $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
            $password = isset($_POST['password']) ? trim($_POST['password']) : '';

            if (!$email || empty($password)) {
                header('Location: login?error=campos_vacios');
                exit;
            }

            // 2. Buscar el usuario en la base de datos
            try {
                // Buscamos por email. Tu db.php ya tiene FETCH_OBJ por defecto.
                $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $usuario = $stmt->fetch(); 

                // 3. Verificar existencia del usuario y comparar el Hash
                // password_verify detectará si el hash coincide con el texto plano
                if ($usuario && password_verify($password, $usuario->password)) {
                    
                    // Iniciar sesión si no existe una previa
                    if (session_status() === PHP_SESSION_NONE) {
                        session_start();
                    }

                    // Seguridad: Cambiar el ID de sesión al loguearse para evitar secuestro de sesión
                    session_regenerate_id(true);

                    // Guardar datos útiles en la sesión
                    $_SESSION['login'] = true;
                    $_SESSION['id'] = $usuario->id;
                    $_SESSION['nombre'] = $usuario->nombre;
                    $_SESSION['email'] = $usuario->email;

                    // Redirigir al área administrativa
                    header('Location: admin/dashboard');
                    exit;
                } else {
                    // Credenciales no coinciden o usuario no existe
                    header('Location: login?error=datos_incorrectos');
                    exit;
                }

            } catch (PDOException $e) {
                // En desarrollo puedes usar die($e->getMessage()), en producción redirige a un error
                header('Location: login?error=db_error');
                exit;
            }
        }
    }

    public function logout() {
        // Asegurar que tenemos acceso a la sesión antes de destruirla
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // 1. Vaciar el array de sesión
        $_SESSION = [];

        // 2. Borrar la cookie de sesión del navegador (opción recomendada de PHP.net)
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }

        // 3. Destruir la sesión en el servidor
        session_destroy();
        
        // Redirigir al inicio o al login
        header('Location: login');
        exit;
    }
}