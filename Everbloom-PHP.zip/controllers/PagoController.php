<?php
// Carga automática de las librerías instaladas (Mercado Pago)
require_once __DIR__ . '/../vendor/autoload.php';

// Importa las clases necesarias de Mercado Pago
use MercadoPago\Client\Preference\PreferenceClient;
use MercadoPago\MercadoPagoConfig;

class PagoController {
    
    public function __construct() {
        // Aquí debes poner tu Access Token de prueba de Mercado Pago
        MercadoPagoConfig::setAccessToken("TU_ACCESS_TOKEN_AQUI");
    }

    public function generarPago($nombreProducto, $precio, $cantidad) {
        $client = new PreferenceClient();
        
        // Creamos la "Preferencia" (lo que el usuario verá al pagar)
        $preference = $client->create([
            "items" => [
                [
                    "title" => $nombreProducto,
                    "quantity" => (int)$cantidad,
                    "unit_price" => (float)$precio,
                    "currency_id" => "PEN" // Moneda para Perú
                ]
            ],
            "back_urls" => [
                "success" => "http://localhost/success.php",
                "failure" => "http://localhost/failure.php"
            ]
        ]);

        return $preference->init_point; // URL para redirigir al cliente al pago
    }
}