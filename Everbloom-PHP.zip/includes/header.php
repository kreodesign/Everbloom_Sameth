<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Everbloom Sameth - Detalles que duran para siempre</title>
    <meta name="description" content="Ramos de rosas de listón satinado hechas a mano en Perú. El regalo eterno que nunca se marchita. Envíos a todo el país.">
    <meta name="keywords" content="rosas eternas, flores de liston, regalo aniversario, Everbloom Sameth, rosas satinadas Lima">

    <meta property="og:type" content="website">
    <meta property="og:title" content="Everbloom Sameth | Detalles que duran para siempre">
    <meta property="og:description" content="Personaliza tu ramo de rosas satinadas. ¡El detalle perfecto que perdura tanto como tus sentimientos!">
    <meta property="og:image" content="/public/img/destacados/6.webp"> <meta property="og:url" content="https://everbloom.pe/">
    <!-- Tailwind CSS -->
    <link rel="stylesheet" href="/public/css/style.css">
    <link rel="stylesheet" href="/public/css/output.css">
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->
    <!-- Font Awesome for WhatsApp Icon -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">

    <link rel="apple-touch-icon" sizes="180x180" href="/public/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/public/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/public/img/favicon/favicon-16x16.png">

    <base href="http://localhost/">

    <!-- Configuración de Tailwind -->
    <!-- <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            light: '#fdf4ff', // Fondo suave
                            primary: '#d946ef', // Rosa fucsia vibrante
                            dark: '#701a75', // Morado profundo
                            accent: '#facc15', // Dorado para detalles
                        }
                    },
                    fontFamily: {
                        serif: ['"Playfair Display"', 'serif'],
                        sans: ['"Lato"', 'sans-serif']
                    }
                }
            }
        }
    </script> -->

    <!-- Placeholder Comments Required -->
    <!-- Chosen Palette: Brand Purple & Pink (Fuchsia-based) with Gold Accents. Minimalist light background (#fdf4ff). -->
    <!-- Application Structure Plan: 
        1. Hero Section: Emotional hook and value proposition.
        2. Market Analysis (Data Viz): Charts proving the value of satin roses vs. fresh flowers (Lifespan, Trends).
        3. Interactive Catalog: Filterable product grid.
        4. "Builder" (Customization Engine): A reactive form that calculates price in real-time based on user selection.
        5. WhatsApp Integration: Generates the final order link.
        Why: This structure guides the user from "Why buy?" (Logic/Data) to "What to buy?" (Catalog) to "How to buy?" (Action), maximizing conversion.
    -->
    <!-- Visualization & Content Choices:
        - Lifespan Comparison Bar Chart: Demonstrates the "Forever" value proposition quantitatively.
        - Color Trends Doughnut Chart: Helps indecisive users choose based on popularity.
        - Dynamic Price Calculator: Pure JS interaction to provide immediate feedback on cost (Critical for user experience).
        - Confirmation: NO SVG graphics used. NO Mermaid JS used.
    -->
    <!-- CONFIRMATION: NO SVG graphics used. NO Mermaid JS used. -->
     <style>
        .animate-fade-in {
            animation: fadeIn 0.3s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>

</head>
<body class="bg-brand-light text-slate-800 font-sans antialiased selection:bg-brand-primary selection:text-white">


    <nav class="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-100 transition-all duration-300">
    <div class="container mx-auto px-6 py-4 flex justify-between items-center">
        
        <a href="home" class="group flex items-center space-x-1 outline-none">
            <img src="/public/img/logo-solo.png" width="45" alt="Logo" class="group-hover:rotate-[10deg] transition-transform duration-500">
            <img src="/public/img/logo-text.png" width="160" alt="Everbloom Sameth" class="opacity-90 group-hover:opacity-100 transition-opacity">
        </a>

        <div class="hidden md:flex items-center space-x-10">
            <a href="home" class="relative text-[13px] uppercase tracking-widest font-bold text-slate-500 hover:text-brand-primary transition-colors group">
                Inicio
                <span class="absolute -bottom-1 left-0 w-0 h-[2px] bg-brand-primary transition-all duration-300 group-hover:w-full"></span>
            </a>
            <a href="por-que-everbloom" class="relative text-[13px] uppercase tracking-widest font-bold text-slate-500 hover:text-brand-primary transition-colors group">
                ¿Por qué Everbloom?
                <span class="absolute -bottom-1 left-0 w-0 h-[2px] bg-brand-primary transition-all duration-300 group-hover:w-full"></span>
            </a>
            
            <div class="relative group">
                <button class="flex items-center gap-1.5 text-[13px] uppercase tracking-widest font-bold text-slate-500 group-hover:text-brand-primary transition-colors outline-none">
                    Catálogo
                    <svg class="w-3.5 h-3.5 transition-transform duration-500 group-hover:rotate-180 text-slate-400 group-hover:text-brand-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7"></path>
                    </svg>
                </button>
                
                <div class="absolute left-1/2 -translate-x-1/2 mt-4 w-64 bg-white/95 backdrop-blur-lg border border-slate-100 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform group-hover:translate-y-0 translate-y-4 z-50 overflow-hidden">
                    <div class="p-3 grid grid-cols-1 gap-1">
                        <a href="catalogo/ramos" class="flex items-center px-4 py-3 rounded-xl hover:bg-brand-primary/5 hover:translate-x-1 transition-all group/item">
                            <span class="text-lg mr-3 group-hover/item:scale-125 transition-transform">💐</span>
                            <span class="text-sm font-medium text-slate-600 group-hover/item:text-brand-primary">Ramos Eternos</span>
                        </a>
                        <a href="catalogo/cajas" class="flex items-center px-4 py-3 rounded-xl hover:bg-brand-primary/5 hover:translate-x-1 transition-all group/item">
                            <span class="text-lg mr-3 group-hover/item:scale-125 transition-transform">📦</span>
                            <span class="text-sm font-medium text-slate-600 group-hover/item:text-brand-primary">Cajas de Ensueño</span>
                        </a>
                        <a href="catalogo/regalos" class="flex items-center px-4 py-3 rounded-xl hover:bg-brand-primary/5 hover:translate-x-1 transition-all group/item">
                            <span class="text-lg mr-3 group-hover/item:scale-125 transition-transform">🎁</span>
                            <span class="text-sm font-medium text-slate-600 group-hover/item:text-brand-primary">Regalos Especiales</span>
                        </a>
                        
                        <div class="my-2 border-t border-slate-50"></div>
                        
                        <a href="catalogo" class="flex items-center justify-center px-4 py-3 bg-slate-50 hover:bg-brand-primary text-slate-700 hover:text-white rounded-xl transition-all font-bold text-xs uppercase tracking-tighter">
                            Explorar Todo el Catálogo
                        </a>
                    </div>
                </div>
            </div>
             <a href="contacto" class="relative text-[13px] uppercase tracking-widest font-bold text-slate-500 hover:text-brand-primary transition-colors group">
                Contacto
                <span class="absolute -bottom-1 left-0 w-0 h-[2px] bg-brand-primary transition-all duration-300 group-hover:w-full"></span>
            </a>
        </div>

        <div class="flex items-center space-x-4">
            <a href="catalogo" class="hidden sm:inline-flex px-6 py-2.5 bg-slate-950 text-white text-[12px] font-bold uppercase tracking-[0.1em] rounded-full hover:bg-brand-primary hover:shadow-lg hover:shadow-brand-primary/30 transition-all duration-300">
                Pedir Ahora
            </a>
            
            <button class="md:hidden text-slate-800 p-1">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
            <button id="theme-toggle" class="p-2 rounded-full bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-300">
                <!-- Icono Sol -->
                <i id="theme-toggle-light-icon" class="fas fa-sun hidden"></i>
                <!-- Icono Luna -->
                <i id="theme-toggle-dark-icon" class="fas fa-moon"></i>
            </button>
        </div>
    </div>
</nav>

<script>
    const themeToggleBtn = document.getElementById('theme-toggle');
    const html = document.documentElement;

    // Al cargar, revisar si ya existía una preferencia
    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        html.classList.add('dark');
    } else {
        html.classList.remove('dark');
    }

    themeToggleBtn.addEventListener('click', () => {
        if (html.classList.contains('dark')) {
            html.classList.remove('dark');
            localStorage.setItem('theme', 'light');
        } else {
            html.classList.add('dark');
            localStorage.setItem('theme', 'dark');
        }
    });
</script>
    