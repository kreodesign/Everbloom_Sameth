<footer class="relative bg-slate-950 text-slate-400 py-20 border-t border-slate-900 overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[1px] bg-gradient-to-r from-transparent via-brand-primary/50 to-transparent"></div>
    <div class="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-48 bg-brand-primary/10 blur-[100px] rounded-full"></div>

    <div class="container mx-auto px-6 relative z-10">
        <div class="grid grid-cols-1 md:grid-cols-12 gap-12 items-start">
            
            <div class="md:col-span-5 flex flex-col items-center md:items-start space-y-6 text-center md:text-left">
                <img src="public/img/logo-text.png" width="200" alt="Everbloom Sameth" class="brightness-125 hover:scale-105 transition-transform duration-500">
                <p class="max-w-xs text-[15px] leading-relaxed font-light italic">
                    "Elevando la elegancia artesanal a través de la suavidad del satín. Momentos que florecen para siempre."
                </p>
                <div class="flex space-x-4 pt-2">
                    <a href="https://instagram.com/" class="group relative p-3 bg-slate-900/50 border border-slate-800 rounded-xl hover:border-brand-primary/50 transition-all">
                        <span class="text-xs font-medium group-hover:text-brand-primary transition-colors">Instagram</span>
                    </a>
                    <a href="https://tiktok.com/" class="group relative p-3 bg-slate-900/50 border border-slate-800 rounded-xl hover:border-brand-primary/50 transition-all">
                        <span class="text-xs font-medium group-hover:text-brand-primary transition-colors">TikTok</span>
                    </a>
                </div>
            </div>

            <div class="md:col-span-3 flex flex-col items-center space-y-4">
                <div class="relative group cursor-default">
                    <div class="absolute -inset-1 bg-gradient-to-r from-brand-primary to-purple-600 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
                    <div class="relative bg-slate-950 border border-slate-800 px-8 py-6 rounded-2xl text-center">
                        <p class="text-slate-500 font-bold tracking-[0.2em] uppercase text-[10px] mb-3">Logística Premium</p>
                        <p class="text-white font-semibold text-sm">Envíos a todo el Perú</p>
                        <span class="inline-block mt-2 text-brand-primary text-xl">🇵🇪</span>
                    </div>
                </div>
            </div>

            <div class="md:col-span-4 flex flex-col items-center md:items-end space-y-6">
                <h4 class="text-white font-semibold tracking-tight text-lg">¿Necesitas ayuda?</h4>
                <div class="flex flex-col items-center md:items-end space-y-3">
                    <a href="contacto" class="group text-sm flex items-center space-x-2 hover:text-white transition-colors">
                        <span class="w-1.5 h-1.5 rounded-full bg-brand-primary opacity-0 group-hover:opacity-100 transition-all mr-2"></span>
                        Contacto Directo
                    </a>
                    <a href="preguntas-frecuentes" class="group text-sm flex items-center space-x-2 hover:text-white transition-colors">
                        <span class="w-1.5 h-1.5 rounded-full bg-brand-primary opacity-0 group-hover:opacity-100 transition-all mr-2"></span>
                        Preguntas Frecuentes
                    </a>
                    <a href="catalogo" class="group text-sm flex items-center space-x-2 hover:text-white transition-colors">
                        <span class="w-1.5 h-1.5 rounded-full bg-brand-primary opacity-0 group-hover:opacity-100 transition-all mr-2"></span>
                        Catálogo Digital
                    </a>
                </div>
            </div>
        </div>

        <div class="mt-20 pt-8 border-t border-slate-900/50 flex flex-col md:row justify-between items-center gap-6 text-[11px] uppercase tracking-[0.15em] text-slate-500">
            <p>&copy; 2026 <span class="text-slate-300">Everbloom Sameth</span>. Artesanía Peruana.</p>
            <div class="flex items-center space-x-8">
                <a href="politicas-de-privacidad" class="hover:text-brand-primary transition-colors">Privacidad</a>
                <span class="w-1 h-1 bg-slate-800 rounded-full"></span>
                <a href="terminos-y-condiciones" class="hover:text-brand-primary transition-colors">Términos</a>
                <span class="w-1 h-1 bg-slate-800 rounded-full"></span>
                <a href="politica-de-cookies" class="hover:text-brand-primary transition-colors">Cookies</a>
            </div>
        </div>
    </div>
</footer>

<script type="module" src="/public/js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>

<div id="cookie-banner" class="fixed bottom-8 left-8 right-8 md:left-auto md:right-8 md:w-[400px] bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-2xl z-[100] transform translate-y-20 opacity-0 transition-all duration-700">
    <div class="flex flex-col gap-6">
        <div>
            <h4 class="font-serif italic text-xl mb-2">Ajustes de privacidad</h4>
            <p class="text-slate-400 text-xs leading-relaxed">Utilizamos cookies para mejorar tu experiencia con nuestras flores. Al navegar, aceptas su uso.</p>
        </div>
        <div class="flex items-center gap-4">
            <button onclick="acceptCookies()" class="flex-1 py-3 bg-brand-primary text-white text-[10px] font-bold uppercase tracking-widest rounded-full hover:bg-white hover:text-slate-900 transition-colors">
                Aceptar
            </button>
            <a href="politica-de-cookies" class="text-[10px] text-slate-500 uppercase tracking-widest hover:text-white">Leer más</a>
        </div>
    </div>
</div>

<script>
    window.onload = () => {
        if (!localStorage.getItem('cookies-accepted')) {
            document.getElementById('cookie-banner')?.classList.remove('translate-y-20', 'opacity-0');
        }
    }
    function acceptCookies() {
        localStorage.setItem('cookies-accepted', 'true');
        document.getElementById('cookie-banner')?.classList.add('translate-y-20', 'opacity-0');
    }
</script>
</body>
</html>