@echo off
title Tailwind CSS Build - Producción
echo Optimizando CSS para Everbloom Sameth...
echo.

:: El comando --minify reduce el peso del archivo al maximo
tailwind.exe -i ./public/css/input.css -o ./public/css/output.css --minify

echo.
echo [OK] El archivo output.css ha sido minificado y optimizado.
echo Puedes subir este archivo al servidor.
echo.
pause