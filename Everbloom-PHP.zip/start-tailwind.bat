@echo off
color a
cls
title Tailwind CSS Watcher - Everbloom
echo Iniciando compilacion de Tailwind CSS...
echo Presiona Ctrl+C para detener.
echo.

:: Ejecuta tailwind con los parametros necesarios
tailwind.exe -i ./public/css/input.css -o ./public/css/output.css --watch

pause