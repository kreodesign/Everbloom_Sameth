import { initCharts } from './modules/charts.js';
import { initCustomizer } from './modules/customizer.js';
import { initCalculator } from './modules/calculator.js';
import { initCarousel } from './modules/carousel.js';
import { initFilters } from './modules/filters.js';
import { initChatbot } from './modules/chatbot.js';
import { initDarkMode } from './modules/darkmode.js';

document.addEventListener('DOMContentLoaded', () => {
    // Función para ejecutar módulos sin que uno rompa al otro
    const safeInit = (initFn, name) => {
        try {
            initFn();
        } catch (e) {
            console.warn(`Módulo ${name} no cargado:`, e.message);
        }
    };

    safeInit(initCharts, 'Charts');
    safeInit(initCustomizer, 'Customizer');
    safeInit(initCalculator, 'Calculator');
    safeInit(initCarousel, 'Carousel');
    safeInit(initFilters, 'Filters');
    safeInit(initDarkMode, 'DarkMode');
    
    // El chatbot al final para asegurar que cargue pase lo que pase
    safeInit(initChatbot, 'Chatbot');
});