/**
 * Everbloom Sameth - Customizer Module
 * Gestiona la personalización visual y el envío de datos a WhatsApp
 */
import { sendWhatsAppMessage } from './whatsapp.js';

export function initCustomizer() {
    const form = document.getElementById('customizer-form');
    
    // Si no estamos en la página del personalizador, salimos silenciosamente
    if (!form) return;

    // Referencias a elementos de la interfaz
    const visualizerColor = document.getElementById('visualizer-color');
    const layerLuces = document.getElementById('layer-luces');
    const totalPriceEl = document.getElementById('total-price');
    const summarySize = document.getElementById('summary-size');
    const summaryColor = document.getElementById('summary-color');
    const extrasList = document.getElementById('extras-list');
    const whatsappBtn = document.getElementById('whatsapp-btn');

    /**
     * Actualiza el resumen visual y el precio total
     */
    const updateOrder = () => {
        let total = parseFloat(form.dataset.basePrice) || 0;

        // 1. Actualizar Tamaño
        const size = form.querySelector('input[name="size"]:checked');
        if (size && summarySize) {
            total += parseFloat(size.dataset.extraPrice);
            summarySize.innerText = `${size.value} Rosas`;
        }

        // 2. Actualizar Color Visual
        const color = form.querySelector('input[name="color-option"]:checked');
        if (color && visualizerColor && summaryColor) {
            visualizerColor.style.backgroundColor = color.dataset.hex;
            summaryColor.innerText = color.value;
        }

        // 3. Actualizar Extras y Capas Visuales
        const extras = form.querySelectorAll('input[name="extras"]:checked');
        if (extrasList) {
            extrasList.innerHTML = '';
            
            // Ocultar capa de luces por defecto y mostrarla solo si se selecciona
            if (layerLuces) layerLuces.classList.add('hidden');

            extras.forEach(ex => {
                const price = parseFloat(ex.dataset.price) || 0;
                total += price;

                // Agregar al resumen de la derecha
                const div = document.createElement('div');
                div.className = 'flex justify-between text-sm animate-fade-in';
                div.innerHTML = `<span>+ ${ex.value}</span> <span class="font-medium">S/ ${price.toFixed(2)}</span>`;
                extrasList.appendChild(div);

                // Lógica visual para las luces
                if (ex.value.toLowerCase().includes('luces') && layerLuces) {
                    layerLuces.classList.remove('hidden');
                }
            });
        }

        // 4. Mostrar precio total
        if (totalPriceEl) {
            totalPriceEl.innerText = `S/ ${total.toFixed(2)}`;
        }
    };

    // Escuchar cambios en cualquier parte del formulario
    form.addEventListener('change', updateOrder);
    
    // Ejecutar una vez al cargar para inicializar valores
    updateOrder();

    /**
     * Manejo del botón de WhatsApp
     */
    if (whatsappBtn) {
        whatsappBtn.addEventListener('click', (e) => {
            e.preventDefault();

            // Recopilar los datos actuales para el mensaje
            const selectedSize = form.querySelector('input[name="size"]:checked');
            const selectedColor = form.querySelector('input[name="color-option"]:checked');
            const selectedExtras = Array.from(form.querySelectorAll('input[name="extras"]:checked'))
                                       .map(ex => ex.value)
                                       .join(', ');

            const data = {
                productName: "Ramo Personalizado Everbloom",
                size: selectedSize ? selectedSize.value : 'Estándar',
                units: 'Rosas',
                color: selectedColor ? selectedColor.value : 'No especificado',
                extras: selectedExtras || 'Sin adicionales',
                total: totalPriceEl?.innerText.replace('S/ ', '') || '0.00'
            };

            // Llamar al módulo unificado de WhatsApp
            sendWhatsAppMessage(data);
        });
    }
}