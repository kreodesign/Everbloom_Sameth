export function initDarkMode() {
    const carousels = document.querySelectorAll('.js-carousel-container');

    carousels.forEach(carousel => {
        let isDown = false;
        let startX;
        let scrollLeft;

        carousel.addEventListener('mousedown', (e) => {
            isDown = true;
            carousel.classList.add('dragging');
            startX = e.pageX - carousel.offsetLeft;
            scrollLeft = carousel.scrollLeft;
            
            carousel.style.scrollSnapType = 'none';
            carousel.style.scrollBehavior = 'auto'; 
        });

        const stopDragging = () => {
            if (!isDown) return;
            isDown = false;
            carousel.classList.remove('dragging');
            carousel.style.scrollSnapType = 'x mandatory';
            carousel.style.scrollBehavior = 'smooth';
        };

        carousel.addEventListener('mouseleave', stopDragging);
        carousel.addEventListener('mouseup', stopDragging);

        carousel.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - carousel.offsetLeft;
            const walk = (x - startX) * 2; 
            carousel.scrollLeft = scrollLeft - walk;
        });
    });
}
