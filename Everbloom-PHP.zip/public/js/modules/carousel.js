export function initCarousel() {
    const container = document.getElementById('carousel-inner');
    
    // 1. Verificación de seguridad
    if (!container) return;
    
    // 2. Esperar a que las imágenes estén disponibles en el objeto window
    const images = window.heroImages || [];
    
    if (images.length === 0) {
        console.warn("Carrusel: No se encontraron imágenes en window.heroImages");
        return;
    }

    // 3. Limpiar contenedor por si PHP dejó algo
    container.innerHTML = '';

    // 4. Crear elementos de imagen
    const elements = images.map((src, i) => {
        const img = document.createElement('img');
        img.src = src;
        img.className = `absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${i === 0 ? 'opacity-100' : 'opacity-0'}`;
        container.appendChild(img);
        return img;
    });

    // 5. Lógica de rotación
    let current = 0;
    if (elements.length > 1) {
        setInterval(() => {
            elements[current].classList.replace('opacity-100', 'opacity-0');
            current = (current + 1) % elements.length;
            elements[current].classList.replace('opacity-0', 'opacity-100');
        }, 4000);
    }
}