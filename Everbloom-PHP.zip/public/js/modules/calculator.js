import { sendWhatsAppMessage } from './whatsapp.js'; // Importa la nueva función

export function initCalculator() {
    const sizeInputs = document.querySelectorAll('input[name="size"]');
    const extraInputs = document.querySelectorAll('.extra-item');
    const outTotal = document.getElementById('final-price');
    const whatsappBtn = document.getElementById('whatsapp-btn');

    if (!outTotal) return;

    const calculate = () => {
        let total = parseFloat(window.basePrice || 0);
        const selectedSize = document.querySelector('input[name="size"]:checked');
        if (selectedSize) total += parseFloat(selectedSize.dataset.price || 0);

        extraInputs.forEach(i => { if (i.checked) total += parseFloat(i.dataset.price || 0); });

        outTotal.textContent = total.toFixed(2);
        return total.toFixed(2);
    };

    // Eventos
    [...sizeInputs, ...extraInputs].forEach(input => 
        input.addEventListener('change', calculate)
    );

    if (whatsappBtn) {
        whatsappBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const total = calculate(); // La función que suma los precios
            
            // Enviamos los datos al nuevo módulo
            sendWhatsAppMessage({
                productName: window.currentProductName,
                size: document.querySelector('input[name="size"]:checked')?.value || '',
                units: window.esRamo ? 'rosas' : 'unidades',
                color: document.getElementById('selected-color-name')?.innerText || 'N/A',
                extras: Array.from(extraInputs).filter(i => i.checked).map(i => i.value).join(', '),
                total: total
            });
        });
    }

    calculate(); // Ejecución inicial
}