export function initCharts() {
    const canvas1 = document.getElementById('lifespanChart');
    if (canvas1) {
        new Chart(canvas1.getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['Rosas Naturales', 'Rosas Everbloom Sameth'],
                datasets: [{
                    label: 'Días de Vida Útil',
                    data: [7, 3650],
                    backgroundColor: ['#e2e8f0', '#d946ef'],
                    borderColor: ['#cbd5e1', '#a21caf'],
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                scales: { y: { type: 'logarithmic' } }
            }
        });
    }

    const canvas2 = document.getElementById('trendsChart');
    if (canvas2) {
        new Chart(canvas2.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['Morado/Lila', 'Rojo Clásico', 'Rosa', 'Azul', 'Otros'],
                datasets: [{
                    data: [40, 25, 20, 10, 5],
                    backgroundColor: ['#701a75', '#ef4444', '#f472b6', '#3b82f6', '#94a3b8'],
                    borderWidth: 0
                }]
            },
            options: { maintainAspectRatio: false, responsive: true }
        });
    }
}