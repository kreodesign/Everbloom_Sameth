export function initFilters() {
    const searchInput = document.getElementById('product-search');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const products = document.querySelectorAll('.product-card');

    if (products.length === 0) return;

    const filterProducts = () => {
        const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
        const category = document.querySelector('.filter-btn.active')?.dataset.category || 'todos';

        products.forEach(p => {
            const name = p.querySelector('h3').textContent.toLowerCase();
            const matchesSearch = name.includes(query);
            const matchesCat = (category === 'todos' || p.dataset.category === category);
            p.style.display = (matchesSearch && matchesCat) ? 'block' : 'none';
        });
    };

    if (searchInput) searchInput.addEventListener('input', filterProducts);
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active', 'bg-brand-dark', 'text-white'));
            btn.classList.add('active', 'bg-brand-dark', 'text-white');
            filterProducts();
        });
    });
}