const PHONE_NUMBER = "51951774812";

export function sendWhatsAppMessage(data) {
    if (!data) {
        // Si no hay datos, abrimos chat directo
        window.open(`https://wa.me/${PHONE_NUMBER}`, '_blank');
        return;
    }
    
    const { productName, size, units, color, extras, total } = data;
    const message = 
        `¡Hola Chic@s! 🌹\n\n` +
        `Me gustaría realizar un pedido:\n\n` +
        `✨ *Producto:* ${productName}\n` +
        `📏 *Cantidad:* ${size} ${units}\n` +
        `🎨 *Color:* ${color}\n` +
        `➕ *Adicionales:* ${extras || 'Ninguno'}\n\n` +
        `💰 *Inversión Estimada: S/ ${total}*`;

    window.open(`https://wa.me/${PHONE_NUMBER}?text=${encodeURIComponent(message)}`, '_blank');
}