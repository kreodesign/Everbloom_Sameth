import { sendWhatsAppMessage } from './whatsapp.js';

export function initChatbot() {
    if (document.getElementById('wa-chat-container')) return;

    // Lógica de mensajes contextuales
    const path = window.location.href;
    let welcomeTitle = "Everbloom Sameth";
    let welcomeMsg = "¡Hola! ✨ Bienvenido a nuestra florería. ¿En qué podemos ayudarte?";

    if (path.includes('catalogo')) {
        welcomeTitle = "Asistente de Catálogo";
        welcomeMsg = "¡Hola! ¿Buscas un color en especial para tu ramo eterno? 🌸";
    } else if (path.includes('producto')) {
        const name = document.getElementById('product-name')?.innerText || "este modelo";
        welcomeTitle = "Asistente de Pedidos";
        welcomeMsg = `¡Hola! El modelo **${name}** es una gran elección. ¿Deseas consultar disponibilidad?`;
    }

    const container = document.createElement('div');
    container.id = 'wa-chat-container';
    container.className = 'fixed bottom-6 right-6 z-[999]';
    container.innerHTML = `
        <div id="wa-window" class="hidden flex-col w-80 sm:w-96 bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 mb-4 animate-fade-in-up">
            <div class="bg-slate-950 p-6 text-white relative">
                <div class="flex items-center gap-4">
                    <img src="public/img/logo-solo.png" class="w-10 h-10 rounded-full border border-white/20">
                    <div>
                        <h4 class="font-bold text-sm">${welcomeTitle}</h4>
                        <p class="text-[9px] text-green-400 uppercase">En línea</p>
                    </div>
                </div>
                <button id="wa-close" class="absolute top-6 right-6 text-white/50 hover:text-white"><i class="fas fa-times"></i></button>
            </div>
            <div class="p-6 bg-slate-50 h-64 overflow-y-auto">
                <div class="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm max-w-[90%]">
                    <p class="text-sm text-slate-700">${welcomeMsg}</p>
                </div>
            </div>
            <div class="p-4 bg-white border-t">
                <button id="wa-start-chat" class="flex items-center justify-center gap-3 w-full py-4 bg-[#25D366] text-white rounded-2xl font-bold text-sm hover:scale-[1.02] transition-all">
                    <i class="fab fa-whatsapp"></i> Iniciar Chat
                </button>
            </div>
        </div>
        <button id="wa-trigger" class="w-16 h-16 bg-[#25D366] text-white rounded-full shadow-2xl flex items-center justify-center text-3xl hover:scale-110 transition-all">
            <i class="fab fa-whatsapp"></i>
        </button>
    `;

    document.body.appendChild(container);

    // Eventos
    document.getElementById('wa-trigger').onclick = () => {
        document.getElementById('wa-window').classList.toggle('hidden');
        document.getElementById('wa-window').classList.toggle('flex');
    };

    document.getElementById('wa-close').onclick = () => {
        document.getElementById('wa-window').classList.add('hidden');
        document.getElementById('wa-window').classList.remove('flex');
    };

    document.getElementById('wa-start-chat').onclick = () => {
        sendWhatsAppMessage(); // Llama al servicio sin datos para chat general
    };
}