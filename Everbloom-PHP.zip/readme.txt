Estructura del Proyecto:
========================

htdocs
├── .gitignore
├── .htaccess
├── admin
│   ├── .htaccess
│   ├── css
│   │   └── styles.css
│   ├── dashboard.php
│   ├── includes
│   │   ├── footer.php
│   │   ├── header.php
│   │   └── sidebar.php
│   ├── index.php
│   ├── js
│   │   └── script.js
│   ├── modals
│   │   ├── modal_add_product.php
│   │   └── modal_edit_product.php
│   └── productos.php
├── composer.json
├── composer.lock
├── composer.phar
├── config
│   ├── db.php
│   └── everbloom_db.sql
├── controllers
│   ├── AdminController.php
│   ├── AuthController.php
│   ├── ContactoController.php
│   └── PagoController.php
├── includes
│   ├── footer.php
│   └── header.php
├── index.php
├── minify.bat
├── models
│   ├── Mensaje.php
│   └── Usuario.php
├── package-lock.json
├── package.json
├── public
│   ├── css
│   │   ├── input.css
│   │   ├── output.css
│   │   └── style.css
│   ├── img
│   │   ├── destacados
│   │   │   ├── 1.webp
│   │   │   ├── 2.webp
│   │   │   ├── 3.webp
│   │   │   ├── 4.webp
│   │   │   ├── 5.webp
│   │   │   └── 6.webp
│   │   ├── favicon
│   │   │   ├── android-chrome-192x192.png
│   │   │   ├── android-chrome-512x512.png
│   │   │   ├── apple-touch-icon.png
│   │   │   ├── favicon-16x16.png
│   │   │   ├── favicon-32x32.png
│   │   │   └── favicon.ico
│   │   ├── logo-solo.png
│   │   ├── logo-text.jpg
│   │   ├── logo-text.png
│   │   ├── logo.jpg
│   │   ├── productos
│   │   │   ├── 1
│   │   │   │   └── 1.webp
│   │   │   ├── 2
│   │   │   │   └── 1.webp
│   │   │   ├── 3
│   │   │   │   └── 1.webp
│   │   │   ├── 34
│   │   │   │   └── 1.webp
│   │   │   ├── 4
│   │   │   │   └── 1.webp
│   │   │   ├── 5
│   │   │   │   └── 1.webp
│   │   │   ├── 6
│   │   │   │   └── 1.webp
│   │   │   └── 7
│   │   │       └── 1.webp
│   │   ├── products
│   │   │   ├── 1.png
│   │   │   ├── 2.jpeg
│   │   │   ├── 3.png
│   │   │   ├── 4.jpeg
│   │   │   ├── amor_eterno
│   │   │   │   ├── 1.png
│   │   │   │   └── 2.jpeg
│   │   │   ├── blue_box
│   │   │   │   ├── 1.png
│   │   │   │   ├── 2.png
│   │   │   │   └── 3.png
│   │   │   ├── domo_cristal
│   │   │   │   ├── 1.png
│   │   │   │   ├── 2.jpeg
│   │   │   │   └── 3.jpeg
│   │   │   ├── everbloom_eternity
│   │   │   │   └── 1.png
│   │   │   ├── noche_mistica
│   │   │   │   └── 1.png
│   │   │   ├── ramo_gigante
│   │   │   │   ├── 1.png
│   │   │   │   ├── 2.png
│   │   │   │   ├── 3.jpeg
│   │   │   │   └── 4.jpeg
│   │   │   └── ramo_rosa
│   │   │       ├── 1.png
│   │   │       ├── 2.png
│   │   │       └── 3.png
│   │   └── ramo.png
│   └── js
│       ├── main.js
│       └── modules
│           ├── calculator.js
│           ├── carousel.js
│           ├── charts.js
│           ├── chatbot.js
│           ├── customizer.js
│           ├── darkmode.js
│           ├── filters.js
│           └── whatsapp.js
├── readme.txt
├── router.php
├── src
├── start-tailwind.bat
├── tailwind.config.js
├── tailwind.exe
└── views
    ├── 404.php
    ├── catalogo.php
    ├── contacto.php
    ├── cookies.php
    ├── faq.php
    ├── home.php
    ├── login.php
    ├── nosotros.php
    ├── porque-everbloom.php
    ├── privacidad.php
    ├── producto.php
    └── terminos.php
