<?php 
// 1. Cargar el controlador
require_once __DIR__ . '/../controllers/ContactoController.php';

// 2. Si hay un POST, ejecutar el controlador
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new ContactoController();
    $controller->enviar();
}

include 'includes/header.php'; 

$mensaje_exito = $_GET['exito'] ?? null;
$mensaje_error = $_GET['error'] ?? null;
?>

<main class="bg-brand-light min-h-screen">
    <section class="relative overflow-hidden bg-slate-950 text-white py-24 border-b border-slate-900">
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/10 blur-[120px] rounded-full -mr-48 -mt-48"></div>
        <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/5 blur-[100px] rounded-full -ml-20 -mb-20"></div>
        
        <div class="container mx-auto px-6 relative z-10 text-center">
            <span class="inline-block px-4 py-1.5 rounded-full border border-brand-primary/30 text-brand-primary text-[10px] uppercase tracking-[0.3em] font-bold mb-6">
                Atención Personalizada
            </span>
            <h1 class="text-5xl md:text-7xl font-serif font-bold mb-6 tracking-tight">
                Hablemos de tu <br> <span class="italic text-brand-primary">próximo detalle</span>
            </h1>
            <p class="max-w-2xl mx-auto text-slate-400 text-lg font-light leading-relaxed">
                ¿Tienes una idea especial o una consulta sobre nuestros ramos eternos? Nuestro equipo está listo para ayudarte a crear un recuerdo inolvidable.
            </p>
        </div>
    </section>

    <section class="py-24 container mx-auto px-6">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-20">
            
            <div class="lg:col-span-5 space-y-12">
                <div>
                    <h2 class="text-3xl font-serif font-bold text-slate-900 mb-8">Canales Directos</h2>
                    
                    <div class="space-y-6">
                        <a href="https://wa.me/51900000000" target="_blank" class="group flex items-center p-6 bg-slate-50 rounded-3xl border border-transparent hover:border-brand-primary/20 hover:bg-white hover:shadow-xl transition-all duration-500">
                            <div class="w-14 h-14 bg-green-500/10 text-green-600 rounded-2xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                                <i class="fab fa-whatsapp"></i>
                            </div>
                            <div class="ml-6">
                                <h4 class="text-sm font-bold uppercase tracking-widest text-slate-400 mb-1">WhatsApp Business</h4>
                                <p class="text-lg font-bold text-slate-800">+51 900 000 000</p>
                            </div>
                            <div class="ml-auto text-slate-300 group-hover:text-brand-primary group-hover:translate-x-2 transition-all">
                                <i class="fas fa-chevron-right"></i>
                            </div>
                        </a>

                        <a href="#" target="_blank" class="group flex items-center p-6 bg-slate-50 rounded-3xl border border-transparent hover:border-brand-primary/20 hover:bg-white hover:shadow-xl transition-all duration-500">
                            <div class="w-14 h-14 bg-pink-500/10 text-pink-600 rounded-2xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                                <i class="fab fa-instagram"></i>
                            </div>
                            <div class="ml-6">
                                <h4 class="text-sm font-bold uppercase tracking-widest text-slate-400 mb-1">Instagram</h4>
                                <p class="text-lg font-bold text-slate-800">@everbloom.sameth</p>
                            </div>
                            <div class="ml-auto text-slate-300 group-hover:text-brand-primary group-hover:translate-x-2 transition-all">
                                <i class="fas fa-chevron-right"></i>
                            </div>
                        </a>

                        <div class="group flex items-center p-6 bg-slate-50 rounded-3xl border border-transparent transition-all duration-500">
                            <div class="w-14 h-14 bg-brand-primary/10 text-brand-primary rounded-2xl flex items-center justify-center text-2xl">
                                <i class="far fa-envelope"></i>
                            </div>
                            <div class="ml-6">
                                <h4 class="text-sm font-bold uppercase tracking-widest text-slate-400 mb-1">Correo Electrónico</h4>
                                <p class="text-lg font-bold text-slate-800">hola@everbloomsameth.com</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="p-10 bg-brand-dark rounded-[2.5rem] text-white relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-brand-primary/20 blur-3xl"></div>
                    <h3 class="text-2xl font-serif font-bold mb-4 relative z-10 text-white">Horario de Atención</h3>
                    <ul class="space-y-3 text-slate-400 relative z-10 font-light">
                        <li class="flex justify-between"><span>Lunes a Viernes</span> <span class="text-white font-medium">9:00 AM - 8:00 PM</span></li>
                        <li class="flex justify-between"><span>Sábados</span> <span class="text-white font-medium">10:00 AM - 6:00 PM</span></li>
                        <li class="flex justify-between text-brand-primary font-bold pt-2"><span>Domingos</span> <span>Bajo pedido previo</span></li>
                    </ul>
                </div>
            </div>

            <div class="lg:col-span-7">
                <div class="bg-white p-8 md:p-12 rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/50">
                    <h3 class="text-3xl font-serif font-bold text-slate-900 mb-2">Envíanos un mensaje</h3>
                    <p class="text-slate-500 mb-10 font-light">Responderemos a tu solicitud en menos de 24 horas.</p>
                    
                    <?php if($mensaje_exito === 'enviado'): ?>
                        <div class="mb-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-2xl text-sm font-medium">
                            ¡Mensaje enviado con éxito! Nos contactaremos contigo pronto.
                        </div>
                    <?php endif; ?>

                    <form action="contacto" method="POST" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-2">
                                <label class="text-[10px] uppercase font-bold tracking-widest text-slate-400 ml-2">Nombre Completo</label>
                                <input type="text" name="nombre" required placeholder="Ej. Lucía Alva" class="w-full px-6 py-4 bg-slate-50 border-transparent focus:bg-white focus:border-brand-primary/30 focus:ring-4 focus:ring-brand-primary/5 rounded-2xl outline-none transition-all text-slate-800 placeholder:text-slate-300">
                            </div>
                            <div class="space-y-2">
                                <label class="text-[10px] uppercase font-bold tracking-widest text-slate-400 ml-2">WhatsApp / Teléfono</label>
                                <input type="tel" name="telefono" required placeholder="900 000 000" class="w-full px-6 py-4 bg-slate-50 border-transparent focus:bg-white focus:border-brand-primary/30 focus:ring-4 focus:ring-brand-primary/5 rounded-2xl outline-none transition-all text-slate-800 placeholder:text-slate-300">
                            </div>
                        </div>

                        <div class="space-y-2">
                            <label class="text-[10px] uppercase font-bold tracking-widest text-slate-400 ml-2">Motivo de consulta</label>
                            <div class="relative">
                                <select name="motivo" class="w-full px-6 py-4 bg-slate-50 border-transparent focus:bg-white focus:border-brand-primary/30 rounded-2xl outline-none transition-all text-slate-800 appearance-none">
                                    <option value="Personalizados">Información sobre pedidos personalizados</option>
                                    <option value="Envios">Consulta sobre envíos a provincia</option>
                                    <option value="Eventos">Ventas corporativas / Eventos</option>
                                    <option value="Otro">Otro motivo</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-6 text-slate-400">
                                    <i class="fas fa-chevron-down text-xs"></i>
                                </div>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <label class="text-[10px] uppercase font-bold tracking-widest text-slate-400 ml-2">Tu mensaje</label>
                            <textarea name="mensaje" rows="5" required placeholder="Cuéntanos qué tienes en mente..." class="w-full px-6 py-4 bg-slate-50 border-transparent focus:bg-white focus:border-brand-primary/30 focus:ring-4 focus:ring-brand-primary/5 rounded-3xl outline-none transition-all text-slate-800 placeholder:text-slate-300 resize-none"></textarea>
                        </div>

                        <button type="submit" class="w-full py-6 bg-brand-dark text-white rounded-full font-bold uppercase tracking-widest text-xs hover:bg-brand-primary shadow-xl hover:shadow-brand-primary/30 transition-all duration-500 active:scale-95">
                            Enviar Mensaje
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </section>

    <section class="pb-24 container mx-auto px-6">
        <div class="relative h-[400px] rounded-[3rem] overflow-hidden group">
            <img src="https://images.unsplash.com/photo-1513151233558-d860c5398176?q=80&w=2070&auto=format&fit=crop" class="w-full h-full object-cover transition duration-700 group-hover:scale-105" alt="Artesanía Everbloom">
            <div class="absolute inset-0 bg-slate-900/40 flex items-center justify-center text-center p-6">
                <div class="max-w-md">
                    <p class="text-white text-3xl font-serif italic mb-4 text-white">"Cada pétalo es una promesa de eternidad."</p>
                    <p class="text-brand-primary font-bold uppercase tracking-[0.2em] text-[10px]">Hecho a mano en Lima, Perú</p>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>