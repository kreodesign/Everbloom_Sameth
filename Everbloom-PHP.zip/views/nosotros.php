<?php include 'includes/header.php'; ?>

<main class="bg-brand-light text-slate-900 overflow-x-hidden">
    
    <section class="relative min-h-screen flex items-center justify-center pt-20">
        <div class="container mx-auto px-6 grid md:grid-cols-12 gap-8 items-center">
            
            <div class="md:col-span-6 z-10 space-y-6">
                <div class="overflow-hidden">
                    <span class="inline-block text-brand-primary uppercase tracking-[0.5em] text-[10px] font-bold animate-slide-up">
                        Est. 2026 • Lima, Perú
                    </span>
                </div>
                <h1 class="text-6xl md:text-8xl font-serif leading-[0.9] text-slate-900 tracking-tighter">
                    Flores que <br> 
                    <span class="italic text-brand-primary">no saben</span> <br> 
                    morir.
                </h1>
                <p class="max-w-sm text-slate-500 font-light text-lg leading-relaxed pt-4">
                    Elevamos el arte del satinado a una experiencia de lujo persistente. Cada pétalo es una promesa de eternidad.
                </p>
                <div class="pt-8">
                    <a href="#historia" class="group flex items-center gap-4 text-xs uppercase tracking-[0.3em] font-bold">
                        <span class="w-12 h-[1px] bg-slate-300 group-hover:w-20 group-hover:bg-brand-primary transition-all duration-500"></span>
                        Descubre la esencia
                    </a>
                </div>
            </div>

            <div class="md:col-span-6 relative mt-12 md:mt-0">
                <div class="relative w-full aspect-[3/4] md:w-[80%] ml-auto overflow-hidden rounded-t-[20rem] shadow-2xl">
                    <img src="public/img/destacados/5.png" class="w-full h-full object-cover scale-110 hover:scale-100 transition-transform duration-1000" alt="Everbloom Detail">
                </div>
                <div class="absolute -bottom-6 -left-6 bg-white p-8 shadow-xl max-w-[240px] hidden md:block border-l-4 border-brand-primary">
                    <p class="text-[10px] uppercase tracking-widest text-slate-400 mb-2">Compromiso</p>
                    <p class="text-sm font-serif italic text-slate-700 font-medium">"La perfección no es una opción, es nuestro estándar artesanal."</p>
                </div>
            </div>
        </div>
    </section>

    <section id="historia" class="py-32 bg-slate-900 text-white relative">
        <div class="absolute top-0 right-0 opacity-10 pointer-events-none">
            <h2 class="text-[20vw] font-serif leading-none -mr-20">Everbloom</h2>
        </div>
        
        <div class="container mx-auto px-6">
            <div class="max-w-3xl">
                <h2 class="text-brand-primary text-xs uppercase tracking-[0.4em] font-bold mb-12">Nuestra Filosofía</h2>
                <p class="text-3xl md:text-5xl font-serif leading-tight">
                    En un mundo de lo efímero, elegimos lo <span class="text-slate-400">permanente</span>. No solo moldeamos listones; capturamos la gratitud en formas que el tiempo no puede desgastar.
                </p>
                
                <div class="grid md:grid-cols-2 gap-12 mt-20 text-slate-400 font-light leading-relaxed">
                    <p>
                        Everbloom Sameth nació bajo el cielo de Lima, buscando transformar la belleza clásica de una rosa en una pieza de diseño que pueda decorar tu vida por años. Cada arreglo pasa por un proceso de curación de color y forma único.
                    </p>
                    <p>
                        Utilizamos tecnología de precisión como la <span class="text-white italic tracking-wider">Silhouette Cameo</span> para personalizar mensajes, fusionando la técnica digital con el alma de lo hecho a mano.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="py-32 container mx-auto px-6">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div class="text-center space-y-2">
                <p class="text-5xl font-serif text-slate-900">100%</p>
                <p class="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">Handmade</p>
            </div>
            <div class="text-center space-y-2">
                <p class="text-5xl font-serif text-slate-900">+50</p>
                <p class="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">Tonos de Satín</p>
            </div>
            <div class="text-center space-y-2">
                <p class="text-5xl font-serif text-slate-900">∞</p>
                <p class="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">Durabilidad</p>
            </div>
            <div class="text-center space-y-2">
                <p class="text-5xl font-serif text-slate-900">Peru</p>
                <p class="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">Origen Lima</p>
            </div>
        </div>
    </section>

    <section class="pb-32 container mx-auto px-6">
        <div class="grid md:grid-cols-3 gap-4 h-[600px]">
            <div class="md:col-span-2 bg-slate-200 rounded-[2rem] overflow-hidden relative group">
                <img src="public/img/destacados/5.png" class="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700" alt="Proceso">
                <div class="absolute bottom-10 left-10 text-white z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                    <p class="font-serif italic text-2xl">La paciencia del artesano</p>
                </div>
                <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </div>
            <div class="bg-brand-primary rounded-[2rem] p-12 flex flex-col justify-center text-white">
                <i class="fas fa-quote-left text-4xl mb-6 opacity-20"></i>
                <p class="text-xl font-serif italic mb-6">"Buscaba algo que mi madre pudiera conservar siempre. Everbloom superó mis expectativas."</p>
                <p class="text-[10px] uppercase tracking-widest font-bold">— Ana R., Cliente VIP</p>
            </div>
        </div>
    </section>

</main>

<?php include 'includes/footer.php'; ?>