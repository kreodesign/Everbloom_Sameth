<?php 
try {
    // 1. Consulta optimizada: Traemos más productos para repartir en los carruseles
    $consulta = $pdo->query("SELECT p.*, c.nombre as categoria_nombre, c.slug as categoria_slug 
                             FROM productos p 
                             JOIN categorias c ON p.categoria_id = c.id 
                             ORDER BY p.id DESC LIMIT 40"); 
    $productos_raw = $consulta->fetchAll(PDO::FETCH_OBJ);

    // 2. Lógica de Agrupación y Límites (Máximo 4 categorías, 10 productos cada una)
    $productosPorCategoria = [];
    foreach ($productos_raw as $p) {
        if (!isset($productosPorCategoria[$p->categoria_nombre])) {
            // Solo permitimos hasta 4 categorías en el Home
            if (count($productosPorCategoria) >= 4) continue;
            $productosPorCategoria[$p->categoria_nombre] = [
                'slug' => $p->categoria_slug,
                'items' => []
            ];
        }
        
        // Máximo 10 productos por carrusel
        if (count($productosPorCategoria[$p->categoria_nombre]['items']) < 10) {
            $productosPorCategoria[$p->categoria_nombre]['items'][] = $p;
        }
    }
} catch (PDOException $e) {
    $productosPorCategoria = [];
}

// 3. Escaneo de imágenes para el Hero Carousel
// Quitamos la barra inicial para que PHP lo encuentre en la carpeta del proyecto
$directorio_lectura = 'public/img/destacados/'; 

$imagenesDestacados = [];
if (is_dir($directorio_lectura)) {
    // Buscamos los archivos
    $archivos = glob($directorio_lectura . "*.{jpg,jpeg,png,gif,webp}", GLOB_BRACE);
    foreach ($archivos as $archivo) {
        // Guardamos la ruta limpia para el navegador
        $imagenesDestacados[] = $archivo; 
    }
}

if (empty($imagenesDestacados)) {
    $imagenesDestacados = ['https://placehold.co/600x800?text=Subir+Fotos+a+Destacados'];
}

include 'includes/header.php';
?>

<!-- HERO SECTION -->
<header class="relative overflow-hidden bg-slate-950 text-white py-24 md:py-40 border-b border-white/5">
    <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 blur-[120px] rounded-full -mr-48 -mt-48"></div>
    <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>

    <div class="container mx-auto px-6 grid md:grid-cols-2 gap-16 items-center relative z-10">
        <div class="text-center md:text-left space-y-8">
            <div class="inline-flex items-center space-x-2 px-3 py-1 bg-white/5 backdrop-blur-md rounded-full border border-white/10">
                <span class="flex h-2 w-2 rounded-full bg-brand-primary animate-pulse"></span>
                <span class="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-300">Artesanía de Lujo</span>
            </div>
            
            <h1 class="text-5xl md:text-7xl font-serif font-bold leading-[1.1]">
                Momentos que <br/>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary via-brand-accent to-brand-dark bg-[length:200%_auto] animate-shimmer-text">florecen siempre</span>
            </h1>
            
            <p class="text-lg md:text-xl text-slate-400 max-w-lg mx-auto md:mx-0 leading-relaxed font-light">
                Descubre la elegancia eterna del satín. Rosas artesanales diseñadas para perdurar tanto como tus recuerdos más preciados.
            </p>

            <div class="flex flex-col sm:flex-row gap-5 justify-center md:justify-start pt-4">
                <button onclick="document.getElementById('colecciones').scrollIntoView({behavior: 'smooth'})" 
                        class="group bg-brand-primary text-white px-10 py-4 rounded-full font-bold hover:bg-white hover:text-brand-dark transition-all duration-300 shadow-xl shadow-brand-primary/20 flex items-center justify-center">
                    Ver Colección
                    <span class="ml-2 group-hover:translate-x-1 transition-transform">→</span>
                </button>
            </div>
        </div>

        <!-- Hero Carousel Placeholder -->
        <div class="relative hidden md:flex justify-center items-center">
            <div class="relative z-20 w-80 h-[450px] overflow-hidden rounded-[2.5rem] p-3 shadow-2xl rotate-3 hover:rotate-0 transition-all duration-700 bg-slate-900 border border-white/10">
                <div id="carousel-inner" class="w-full h-full rounded-[2rem] overflow-hidden bg-slate-800">
                    <!-- Aquí se cargan las imágenes por JS -->
                </div>
            </div>
            <div class="absolute -bottom-6 -right-6 w-32 h-32 bg-brand-accent/20 blur-2xl rounded-full"></div>
        </div>
    </div>
</header>

<main id="colecciones" class="bg-white dark:bg-slate-950 py-24 relative transition-colors duration-500">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none overflow-hidden">
        <div class="absolute top-24 left-10 w-96 h-96 bg-brand-primary/5 dark:bg-brand-primary/10 blur-[120px] rounded-full"></div>
    </div>

    <div class="container mx-auto px-6 relative z-10">
        <?php foreach ($productosPorCategoria as $nombreCat => $data): ?>
            <div class="mb-24 last:mb-0">
                <div class="flex justify-between items-end mb-10">
                    <div>
                        <span class="text-brand-primary text-[10px] font-black uppercase tracking-[0.4em] mb-2 block">Colección</span>
                        <h2 class="text-4xl md:text-5xl font-serif text-slate-900 dark:text-white italic tracking-tight">
                            <?= $nombreCat ?>
                        </h2>
                    </div>
                    <a href="catalogo/<?= $data['slug'] ?>" class="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-brand-primary dark:text-slate-500 dark:hover:text-brand-primary transition-all border-b border-slate-200 dark:border-slate-800 hover:border-brand-primary pb-1">
                        Explorar Todo
                    </a>
                </div>

                <div class="relative group">
                    <div class="js-carousel-container flex gap-8 overflow-x-auto pb-12 snap-x snap-mandatory scrollbar-hide">
                        <?php foreach ($data['items'] as $p): ?>
                            <div class="js-card min-w-[200px] max-w-[240px] md:min-w-[280px] md:max-w-[320px] flex-shrink-0 snap-start">
                                <div class="group/card flex flex-col bg-slate-50 dark:bg-slate-900/40 border border-slate-100 dark:border-white/5 rounded-[2.5rem] overflow-hidden hover:shadow-2xl hover:shadow-brand-primary/10 dark:hover:border-brand-primary/30 transition-all duration-500">
                                    
                                    <div class="relative aspect-square overflow-hidden bg-slate-200 dark:bg-slate-800">
                                        <div class="absolute inset-0 bg-slate-200 dark:bg-slate-800 animate-pulse skeleton-overlay"></div>
                                        
                                        <img src="/public/img/productos/<?= $p->id ?>/<?= $p->imagen_principal ?: '1.webp' ?>" 
                                             onload="this.previousElementSibling.remove()"
                                             class="w-full h-full object-cover transition-transform duration-1000 group-hover/card:scale-110"
                                             alt="<?= htmlspecialchars($p->nombre) ?>">
                                        
                                        <div class="absolute bottom-6 left-6">
                                            <span class="bg-white/90 dark:bg-slate-950/90 backdrop-blur-md text-slate-900 dark:text-white text-xs font-black px-4 py-2 rounded-xl border border-white/20 shadow-xl">
                                                S/ <?= number_format($p->precio_base, 2) ?>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="p-8 text-center">
                                        <h3 class="text-slate-800 dark:text-slate-200 font-serif text-2xl mb-6 group-hover/card:text-brand-primary transition-colors line-clamp-1 italic">
                                            <?= $p->nombre ?>
                                        </h3>
                                        <a href="producto/<?= $p->id ?>" class="inline-block w-full py-4 bg-slate-900 dark:bg-slate-950 text-white dark:text-slate-400 text-[10px] uppercase font-bold tracking-[0.2em] rounded-2xl border border-transparent dark:border-slate-800 hover:bg-brand-primary dark:hover:bg-brand-primary dark:hover:text-white transition-all duration-300">
                                            Personalizar Detalle
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <div class="min-w-[250px] flex items-center justify-center snap-start pr-12">
                             <a href="catalogo/<?= $data['slug'] ?>" class="group flex flex-col items-center gap-6">
                                <div class="w-20 h-20 rounded-full border-2 border-slate-100 dark:border-slate-800 flex items-center justify-center group-hover:border-brand-primary group-hover:bg-brand-primary/5 transition-all duration-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-slate-300 group-hover:text-brand-primary transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                    </svg>
                                </div>
                                <span class="text-[10px] uppercase font-black tracking-[0.4em] text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white transition-colors text-center">Ver Colección<br>Completa</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

 <!-- Carousel Main Scripts -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const carousels = document.querySelectorAll('.js-carousel-container');

    carousels.forEach(carousel => {
        let isDown = false;
        let startX;
        let scrollLeft;

        carousel.addEventListener('mousedown', (e) => {
            isDown = true;
            carousel.classList.add('dragging');
            startX = e.pageX - carousel.offsetLeft;
            scrollLeft = carousel.scrollLeft;
            
            carousel.style.scrollSnapType = 'none';
            carousel.style.scrollBehavior = 'auto'; 
        });

        const stopDragging = () => {
            if (!isDown) return;
            isDown = false;
            carousel.classList.remove('dragging');
            carousel.style.scrollSnapType = 'x mandatory';
            carousel.style.scrollBehavior = 'smooth';
        };

        carousel.addEventListener('mouseleave', stopDragging);
        carousel.addEventListener('mouseup', stopDragging);

        carousel.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - carousel.offsetLeft;
            const walk = (x - startX) * 2; 
            carousel.scrollLeft = scrollLeft - walk;
        });
    });
});
</script>


 <!-- Hero Carousel -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('carousel-inner');
    const images = window.heroImages;
    let currentIndex = 0;

    if (!container || images.length === 0) return;

    // Función para crear la imagen con estilo
    const createImageElement = (src) => {
        const img = document.createElement('img');
        img.src = src;
        img.className = 'absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-1000 ease-in-out';
        return img;
    };

    // Colocar la primera imagen inmediatamente
    const firstImg = createImageElement(images[0]);
    container.appendChild(firstImg);
    setTimeout(() => firstImg.classList.remove('opacity-0'), 50);

    // Si hay más de una imagen, empezar la rotación
    if (images.length > 1) {
        setInterval(() => {
            currentIndex = (currentIndex + 1) % images.length;
            const newImg = createImageElement(images[currentIndex]);
            const oldImg = container.querySelector('img');

            container.appendChild(newImg);
            
            setTimeout(() => {
                newImg.classList.remove('opacity-0');
                if (oldImg) {
                    oldImg.classList.add('opacity-0');
                    setTimeout(() => oldImg.remove(), 1000);
                }
            }, 50);
        }, 5000); // Cambia cada 5 segundos
    }
});
</script>


<script>
    // Pasar imágenes al Hero Carousel (manteniendo tu lógica actual)
    window.heroImages = <?php echo json_encode($imagenesDestacados); ?>;
</script>

<?php include 'includes/footer.php'; ?>