<?php

include 'includes/header.php';
echo password_hash('admin123', PASSWORD_BCRYPT);
?>

<main class="bg-slate-950 min-h-screen flex items-center justify-center relative overflow-hidden py-20">
    <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/10 blur-[120px] rounded-full -mr-48 -mt-48"></div>
    <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/5 blur-[100px] rounded-full -ml-20 -mb-20"></div>

    <div class="container mx-auto px-6 relative z-10">
        <div class="max-w-md mx-auto">
            
            <div class="text-center mb-10">
                <span class="inline-block px-4 py-1.5 rounded-full border border-brand-primary/30 text-brand-primary text-[10px] uppercase tracking-[0.3em] font-bold mb-4">
                    Panel Administrativo
                </span>
                <h1 class="text-4xl font-serif font-bold text-white tracking-tight">
                    Bienvenido de <span class="italic text-brand-primary">nuevo</span>
                </h1>
            </div>

            <div class="bg-white/5 backdrop-blur-xl p-8 md:p-10 rounded-[2.5rem] border border-white/10 shadow-2xl">
                
                <?php if(isset($_GET['error'])): ?>
                    <div class="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl text-xs text-center font-medium">
                        <?php 
                            if($_GET['error'] === 'campos_vacios') echo 'Todos los campos son obligatorios';
                            if($_GET['error'] === 'datos_incorrectos') echo 'Credenciales no válidas';
                        ?>
                    </div>
                <?php endif; ?>

                <form action="auth" method="POST" class="space-y-6">
                    <div class="space-y-2">
                        <label class="text-[10px] uppercase font-bold tracking-widest text-slate-500 ml-2">Correo Electrónico</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-6 text-slate-500">
                                <i class="far fa-envelope"></i>
                            </span>
                            <input type="email" name="email" required placeholder="admin@everbloom.com" 
                                class="w-full pl-14 pr-6 py-4 bg-white/5 border border-white/10 focus:border-brand-primary/50 focus:ring-4 focus:ring-brand-primary/5 rounded-2xl outline-none transition-all text-white placeholder:text-slate-600">
                        </div>
                    </div>

                    <div class="space-y-2">
                        <label class="text-[10px] uppercase font-bold tracking-widest text-slate-500 ml-2">Contraseña</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-6 text-slate-500">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" name="password" required placeholder="••••••••" 
                                class="w-full pl-14 pr-6 py-4 bg-white/5 border border-white/10 focus:border-brand-primary/50 focus:ring-4 focus:ring-brand-primary/5 rounded-2xl outline-none transition-all text-white placeholder:text-slate-600">
                        </div>
                    </div>

                    <button type="submit" class="w-full py-5 bg-brand-primary text-white rounded-full font-bold uppercase tracking-widest text-xs hover:bg-white hover:text-brand-dark shadow-xl shadow-brand-primary/20 transition-all duration-500 active:scale-95 mt-4">
                        Entrar al Panel
                    </button>
                </form>

                <div class="mt-8 text-center">
                    <a href="/" class="text-slate-500 text-[10px] uppercase tracking-widest hover:text-brand-primary transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Volver a la web
                    </a>
                </div>
            </div>

            <p class="text-center mt-10 text-slate-600 text-[10px] uppercase tracking-[0.2em]">
                &copy; <?= date('Y') ?> Everbloom Sameth - Lima, Perú
            </p>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>