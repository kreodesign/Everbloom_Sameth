<?php include 'includes/header.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<main class="bg-[#FCFCFC] text-slate-900 pb-32">
    
    <header class="relative overflow-hidden bg-slate-950 text-white py-24 md:py-40">

    <!-- Fondo decorativo -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 blur-[120px] rounded-full -mr-48 -mt-48"></div>
        <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>
        
        <div class="container mx-auto px-6 text-center">
            <span class="text-brand-primary uppercase tracking-[0.5em] text-[10px] font-bold mb-4 block">Inversión Emocional</span>
            <h1 class="text-5xl md:text-8xl font-serif tracking-tighter leading-none">
                La ciencia de un <br>
                <span class="italic text-brand-primary">recuerdo eterno</span>
            </h1>
        </div>
    </header>

    <section class="container mx-auto px-6">
        <div class="max-w-4xl mx-auto my-20">
            <div class="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <h2 class="text-3xl font-serif mb-6">¿Por qué elegir Rosas Everbloom?</h2>
                    <p class="text-slate-500 font-light leading-relaxed">
                        Analizamos el valor real de tu inversión. A diferencia de las flores naturales, nuestros ramos satinados son un patrimonio emocional permanente que combina el arte manual con una durabilidad infinita.
                    </p>
                </div>
                <div class="border-l border-slate-200 pl-8">
                    <p class="text-xs uppercase tracking-widest text-slate-400 mb-2 font-bold">Dato Clave</p>
                    <p class="text-2xl font-serif italic text-brand-primary">"Un ramo natural dura 7 días; Everbloom dura para siempre."</p>
                </div>
            </div>
        </div>

        <div class="grid md:grid-cols-2 gap-8">
            
            <div class="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-50 hover:shadow-xl transition-shadow duration-700">
                <div class="mb-8">
                    <h3 class="text-xs uppercase tracking-[0.3em] font-bold text-slate-400">01. Ciclo de Vida</h3>
                    <p class="text-2xl font-serif mt-2 text-slate-900">Comparativa de Durabilidad</p>
                    <p class="text-sm text-slate-400 italic">Días de esplendor antes del deterioro</p>
                </div>
                
                <div class="relative h-[300px]">
                    <canvas id="lifespanChart"></canvas>
                </div>

                <div class="mt-8 bg-slate-50 p-6 rounded-2xl flex items-center gap-4">
                    <span class="text-4xl text-brand-primary font-serif">∞</span>
                    <p class="text-[11px] uppercase tracking-widest leading-relaxed font-bold text-slate-600">
                        Nuestras rosas no requieren hidratación ni mantenimiento, conservando su brillo original por años.
                    </p>
                </div>
            </div>

            <div class="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-50 hover:shadow-xl transition-shadow duration-700">
                <div class="mb-8">
                    <h3 class="text-xs uppercase tracking-[0.3em] font-bold text-slate-400">02. Estética 2026</h3>
                    <p class="text-2xl font-serif mt-2 text-slate-900">Tendencias de Color</p>
                    <p class="text-sm text-slate-400 italic">Preferencia de nuestra comunidad</p>
                </div>
                
                <div class="relative h-[300px]">
                    <canvas id="trendsChart"></canvas>
                </div>

                <div class="mt-8 text-center">
                    <p class="text-sm text-slate-500 italic font-light">
                        El <span class="text-brand-primary font-medium">Morado y Lila</span> dominan esta temporada, simbolizando la admiración profunda y la elegancia contemporánea.
                    </p>
                </div>
            </div>

        </div>
    </section>

    <section class="mt-32 container mx-auto px-6">
        <div class="bg-slate-900 rounded-[4rem] p-12 md:p-20 text-center relative overflow-hidden">
            <div class="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                <div class="absolute top-[-10%] right-[-5%] w-64 h-64 bg-brand-primary rounded-full blur-[100px]"></div>
            </div>
            <h2 class="text-white text-4xl md:text-6xl font-serif mb-8 relative z-10">¿Listo para regalar algo <br><span class="italic text-brand-primary">que perdure?</span></h2>
            <a href="catalogo" class="inline-block bg-white text-slate-900 px-10 py-5 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-brand-primary hover:text-white transition-all duration-500 relative z-10">
                Explorar Colección
            </a>
        </div>
    </section>

</main>

<script>
// Configuración de Gráficos con Estilo Minimalista
const ctx1 = document.getElementById('lifespanChart').getContext('2d');
const ctx2 = document.getElementById('trendsChart').getContext('2d');

// Fuentes y colores compartidos
const fontConfig = { family: 'serif', size: 12 };

new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: ['Naturales', 'Preservadas', 'Everbloom'],
        datasets: [{
            label: 'Días de Vida',
            data: [7, 365, 2000], // 2000 como representación de infinito/largo plazo
            backgroundColor: ['#E2E8F0', '#CBD5E1', '#E2A59A'], // Slate-200, Slate-300, Brand-Primary
            borderRadius: 20,
            borderSkipped: false,
            barPercentage: 0.6
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { display: false },
            x: { 
                grid: { display: false },
                ticks: { font: fontConfig, color: '#64748b' }
            }
        }
    }
});

new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Morado/Lila', 'Rojo Clásico', 'Rosa Soft', 'Otros'],
        datasets: [{
            data: [45, 25, 20, 10],
            backgroundColor: ['#9333EA', '#BE123C', '#FDA4AF', '#F1F5F9'],
            borderWidth: 0,
            hoverOffset: 20
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '80%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: { usePointStyle: true, font: fontConfig, padding: 20 }
            }
        }
    }
});
</script>

<?php include 'includes/footer.php'; ?>