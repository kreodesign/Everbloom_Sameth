<?php 
require_once 'config/db.php';
$categoria_slug = isset($_GET['id']) ? $_GET['id'] : null;

try {
    // 1. Obtener categorías para los filtros
    $catStmt = $pdo->query("SELECT * FROM categorias");
    $categorias = $catStmt->fetchAll();

    // 2. Lógica de filtrado
    if ($categoria_slug && $categoria_slug !== 'all') {
        $stmt = $pdo->prepare("SELECT p.*, c.nombre as categoria_nombre FROM productos p 
                               JOIN categorias c ON p.categoria_id = c.id 
                               WHERE c.slug = ? ORDER BY p.id DESC");
        $stmt->execute([$categoria_slug]);
        $productos = $stmt->fetchAll();
        $titulo_dinamico = !empty($productos) ? $productos[0]->categoria_nombre : "Colección";
    } else {
        $productos = $pdo->query("SELECT p.*, c.nombre as categoria_nombre FROM productos p 
                                  JOIN categorias c ON p.categoria_id = c.id ORDER BY p.id DESC")->fetchAll();
        $titulo_dinamico = "Everbloom";
    }
} catch (PDOException $e) { $productos = []; }

include 'includes/header.php'; 
?>

<main class="relative overflow-hidden bg-slate-950 text-white pb-24 md:pb-40">
    <header class="relative pt-24 pb-12">
        <div class="container mx-auto px-6 text-center">
            <h1 class="text-4xl md:text-6xl font-serif mb-8 text-white">
                Colección <span class="italic text-brand-primary"><?= $titulo_dinamico ?></span>
            </h1>
            
            <!-- Filtros más compactos -->
            <div class="flex flex-wrap gap-2 justify-center pb-8">
                <?php foreach($categorias as $cat): ?>
                    <a href="catalogo/<?= $cat->slug ?>" 
                    class="px-5 py-2 text-[9px] uppercase font-bold tracking-tighter border border-white/10 rounded-full transition-all <?= $categoria_slug === $cat->slug ? 'bg-brand-primary text-white border-brand-primary' : 'text-slate-400 hover:border-white/40 hover:text-white' ?>">
                        <?= $cat->nombre ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </header>

    <section class="container mx-auto px-6 relative z-10">
        <?php if(empty($productos)): ?>
            <div class="text-center py-20">
                <p class="text-slate-500 font-serif italic text-xl">No hay productos disponibles en esta categoría.</p>
            </div>
        <?php else: ?>
            <!-- Contenedor con 4 columnas en pantallas grandes para que se vea más profesional -->
            <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                <?php foreach($productos as $prod): ?>
                <div class="group relative flex flex-col bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-brand-primary/40 transition-all duration-500">
                    
                    <div class="relative aspect-[4/5] overflow-hidden bg-slate-200">
                        <div class="absolute inset-0 bg-slate-800 animate-pulse skeleton-overlay"></div>
                        
                        <img src="/public/img/productos/<?= $prod->id ?>/<?= $prod->imagen_principal ?: '1.webp' ?>" 
                            onload="this.previousElementSibling.remove()" 
                            class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                            alt="<?= htmlspecialchars($prod->nombre) ?>">

                        <div class="absolute top-3 left-3">
                            <span class="bg-slate-950/80 backdrop-blur-md text-brand-primary text-[8px] font-bold px-2 py-1 rounded-md border border-brand-primary/20 uppercase tracking-tighter">
                                <?= $prod->categoria_nombre ?>
                            </span>
                        </div>
                    </div>

                    <div class="p-4 flex flex-col flex-1">
                        <h3 class="text-sm md:text-base font-serif font-medium text-slate-200 mb-1 group-hover:text-brand-primary transition-colors">
                            <?= $prod->nombre ?>
                        </h3>
                        
                        <div class="flex items-center justify-between mt-auto pt-3 border-t border-slate-800/50">
                            <span class="text-white font-bold text-sm">S/ <?= number_format($prod->precio_base, 2) ?></span>
                            
                            <a href="producto/<?= $prod->id ?>" class="text-slate-500 group-hover:text-brand-primary transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="mt-32 text-center">
            <div class="inline-block p-[1px] rounded-full bg-gradient-to-r from-transparent via-brand-primary to-transparent">
                <a href="contacto" class="inline-flex items-center gap-4 bg-slate-950 text-white px-12 py-5 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-brand-primary transition-all duration-700">
                    <i class="fab fa-whatsapp text-lg"></i> Personalizar mi pedido
                </a>
            </div>
        </div>
    </section>

    <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>
</main>
<?php
include 'includes/footer.php'; 
?>