<?php include 'includes/header.php'; ?>

<main class="bg-[#FCFCFC] text-slate-900 pb-32">
    <header class="relative overflow-hidden bg-slate-950 text-white py-24 md:py-40">

    <!-- Fondo decorativo -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 blur-[120px] rounded-full -mr-48 -mt-48"></div>
        <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>

        <div class="container mx-auto px-6">
            <span class="text-brand-primary uppercase tracking-[0.5em] text-[10px] font-bold mb-4 block">Experiencia Digital</span>
            <h1 class="text-5xl md:text-7xl font-serif tracking-tighter">Política de <br><span class="italic text-brand-primary">Cookies</span></h1>
            <p class="mt-8 text-slate-400 text-sm tracking-widest uppercase">Versión 1.0 • Everbloom Sameth</p>
            <p class="mt-4 text-slate-400 max-w-lg leading-relaxed font-light">En Everbloom Sameth, nos comprometemos a brindarte una experiencia de navegación transparente y segura. Esta política de cookies explica qué son las cookies, cómo las utilizamos en nuestro sitio web y cómo puedes gestionar tus preferencias.</p>
        </div>
    </header>

    <section class="container mx-auto px-6 mt-20">
        <div class="grid md:grid-cols-12 gap-16">
            
            <div class="md:col-span-4">
                <p class="text-xl font-serif italic text-slate-500 leading-relaxed">
                    "Utilizamos la tecnología para que tu navegación sea tan fluida como el satín de nuestras rosas."
                </p>
            </div>

            <div class="md:col-span-8 space-y-16 leading-relaxed font-light text-slate-600">
                
                <article class="space-y-6">
                    <h2 class="text-2xl font-serif text-slate-900 italic">¿Qué son las cookies?</h2>
                    <p>
                        Una cookie es un pequeño archivo de texto que se almacena en tu navegador cuando visitas casi cualquier sitio web. Su utilidad es que la web sea capaz de recordar tu visita cuando vuelvas a navegar por esa página, como por ejemplo, recordar tus preferencias de visualización en nuestro catálogo.
                    </p>
                </article>

                <article class="space-y-8">
                    <h2 class="text-2xl font-serif text-slate-900 italic">Cookies que utilizamos</h2>
                    
                    <div class="space-y-6">
                        <div class="p-8 border border-slate-100 rounded-[2rem] hover:bg-white hover:shadow-xl transition-all duration-500">
                            <h4 class="text-slate-900 font-bold text-xs uppercase tracking-widest mb-3 flex items-center gap-2">
                                <span class="w-2 h-2 bg-brand-primary rounded-full"></span>
                                Técnicas (Necesarias)
                            </h4>
                            <p class="text-sm">Son esenciales para que puedas navegar por la web y usar sus funciones, como acceder al panel administrativo o ver correctamente las imágenes de los productos.</p>
                        </div>

                        <div class="p-8 border border-slate-100 rounded-[2rem] hover:bg-white hover:shadow-xl transition-all duration-500">
                            <h4 class="text-slate-900 font-bold text-xs uppercase tracking-widest mb-3 flex items-center gap-2">
                                <span class="w-2 h-2 bg-blue-400 rounded-full"></span>
                                Analíticas
                            </h4>
                            <p class="text-sm">Nos permiten cuantificar el número de usuarios y realizar la medición y análisis estadístico de cómo los clientes usan nuestro catálogo, con el fin de mejorar la oferta de flores y servicios que te ofrecemos.</p>
                        </div>
                    </div>
                </article>

                <article class="space-y-6">
                    <h2 class="text-2xl font-serif text-slate-900 italic">Cómo gestionar tus preferencias</h2>
                    <p>
                        Puedes permitir, bloquear o eliminar las cookies instaladas en tu equipo mediante la configuración de las opciones del navegador instalado en tu ordenador o dispositivo móvil:
                    </p>
                    <div class="flex flex-wrap gap-4 pt-4">
                        <span class="px-4 py-2 bg-slate-100 rounded-full text-[10px] font-bold uppercase tracking-widest">Google Chrome</span>
                        <span class="px-4 py-2 bg-slate-100 rounded-full text-[10px] font-bold uppercase tracking-widest">Safari</span>
                        <span class="px-4 py-2 bg-slate-100 rounded-full text-[10px] font-bold uppercase tracking-widest">Firefox</span>
                    </div>
                </article>

            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>