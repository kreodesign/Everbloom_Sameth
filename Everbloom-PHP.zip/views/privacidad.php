<?php include 'includes/header.php'; ?>

<main class="bg-[#FCFCFC] text-slate-900 pb-32">
    <header class="relative overflow-hidden bg-slate-950 text-white py-24 md:py-40">

    <!-- Fondo decorativo -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 blur-[120px] rounded-full -mr-48 -mt-48"></div>
        <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>

        <div class="container mx-auto px-6">
            <span class="text-brand-primary uppercase tracking-[0.5em] text-[10px] font-bold mb-4 block">Transparencia</span>
            <h1 class="text-5xl md:text-7xl font-serif tracking-tighter">Políticas de <br><span class="italic text-brand-primary">Privacidad</span></h1>
            <p class="mt-8 text-slate-400 text-sm tracking-widest uppercase">Última actualización: Marzo 2026</p>
            <p class="mt-4 text-slate-400 max-w-lg leading-relaxed font-light">En Everbloom Sameth, tu privacidad es tan valiosa como nuestras rosas eternas. Esta política explica cómo protegemos tu información personal y garantizamos una experiencia de compra segura.</p>
        </div>
    </header>

    <section class="container mx-auto px-6 mt-20">
        <div class="grid md:grid-cols-12 gap-16">
            
            <aside class="hidden md:block md:col-span-4 sticky top-32 h-fit">
                <nav class="space-y-4 border-l border-slate-100 pl-6">
                    <a href="#introduccion" class="block text-xs uppercase tracking-widest text-slate-400 hover:text-brand-primary transition-colors">01. Introducción</a>
                    <a href="#datos" class="block text-xs uppercase tracking-widest text-slate-400 hover:text-brand-primary transition-colors">02. Datos recolectados</a>
                    <a href="#finalidad" class="block text-xs uppercase tracking-widest text-slate-400 hover:text-brand-primary transition-colors">03. Finalidad del tratamiento</a>
                    <a href="#derechos" class="block text-xs uppercase tracking-widest text-slate-400 hover:text-brand-primary transition-colors">04. Tus derechos (ARCO)</a>
                </nav>
            </aside>

            <div class="md:col-span-8 space-y-16 leading-relaxed font-light text-slate-600">
                
                <article id="introduccion" class="space-y-6">
                    <h2 class="text-2xl font-serif text-slate-900 italic">01. Introducción</h2>
                    <p>
                        En <strong>Everbloom Sameth</strong>, valoramos la confianza que depositas en nosotros al elegir nuestras rosas eternas. Esta política detalla cómo protegemos tu información personal y garantizamos que tu experiencia de compra sea segura y privada, de acuerdo con la Ley de Protección de Datos Personales en Perú.
                    </p>
                </article>

                <article id="datos" class="space-y-6">
                    <h2 class="text-2xl font-serif text-slate-900 italic">02. Datos que recolectamos</h2>
                    <p>Para procesar tus pedidos personalizados, solicitamos la siguiente información:</p>
                    <ul class="space-y-4 pl-6 border-l-2 border-brand-primary/20">
                        <li><strong>Identificación:</strong> Nombre completo para la entrega.</li>
                        <li><strong>Contacto:</strong> Correo electrónico y número de WhatsApp.</li>
                        <li><strong>Personalización:</strong> Mensajes o dedicatorias que desees incluir en tus arreglos.</li>
                        <li><strong>Navegación:</strong> Cookies técnicas para mejorar el funcionamiento del catálogo.</li>
                    </ul>
                </article>

                <article id="finalidad" class="space-y-6">
                    <h2 class="text-2xl font-serif text-slate-900 italic">03. ¿Para qué usamos tu información?</h2>
                    <p>Los datos proporcionados tienen objetivos estrictamente operativos:</p>
                    <div class="grid sm:grid-cols-2 gap-8 pt-4">
                        <div class="p-6 bg-slate-50 rounded-2xl">
                            <h4 class="text-slate-900 font-bold text-xs uppercase mb-2">Gestión de Pedidos</h4>
                            <p class="text-sm">Coordinar la fabricación artesanal y el envío a tu domicilio en Lima o provincias.</p>
                        </div>
                        <div class="p-6 bg-slate-50 rounded-2xl">
                            <h4 class="text-slate-900 font-bold text-xs uppercase mb-2">Atención Directa</h4>
                            <p class="text-sm">Resolver dudas vía WhatsApp sobre colores de listón y estados de envío.</p>
                        </div>
                    </div>
                </article>

                <article id="derechos" class="space-y-6">
                    <h2 class="text-2xl font-serif text-slate-900 italic">04. Tus Derechos</h2>
                    <p>
                        Eres dueño de tus datos. En cualquier momento puedes solicitar el acceso, rectificación, cancelación u oposición (Derechos ARCO) de tu información enviando un mensaje directo a nuestras líneas de atención oficiales.
                    </p>
                    <div class="pt-10">
                        <blockquote class="border-t border-b border-slate-100 py-8 text-center italic font-serif text-xl text-slate-400">
                            "Tu privacidad es tan eterna como nuestras rosas."
                        </blockquote>
                    </div>
                </article>

            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>