<?php include 'includes/header.php'; ?>

<main class="bg-slate-950 min-h-screen flex items-center justify-center text-center px-6">
    <div class="max-w-md">
        <h1 class="text-9xl font-serif font-bold text-brand-primary opacity-20">404</h1>
        <div class="relative -mt-20">
            <h2 class="text-4xl font-serif font-bold text-white mb-4">Página no encontrada</h2>
            <p class="text-slate-400 mb-10 text-lg">Parece que este pétalo se ha perdido en el camino. La página que buscas no existe o fue movida.</p>
            <a href="/" class="inline-block px-10 py-4 bg-brand-primary text-white rounded-full font-bold uppercase tracking-widest text-xs hover:bg-white hover:text-brand-dark transition-all shadow-xl shadow-brand-primary/20">
                Volver al Inicio
            </a>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>