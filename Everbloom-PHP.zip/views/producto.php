<?php
include 'includes/header.php';

require_once 'config/db.php';

// 1. Obtención de ID y validación
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id === 0) {
    header("Location: index.php");
    exit;
}

try {
    // 2. Traer información del producto y su categoría
    $stmt = $pdo->prepare("SELECT p.*, c.nombre as categoria_nombre 
                           FROM productos p 
                           LEFT JOIN categorias c ON p.categoria_id = c.id 
                           WHERE p.id = ?");
    $stmt->execute([$id]);
    $producto = $stmt->fetch(PDO::FETCH_OBJ);

    if (!$producto) {
        header("Location: index.php");
        exit;
    }

    // 3. Traer variaciones (cantidad de rosas / tamaño)
    $stmtVar = $pdo->prepare("SELECT * FROM producto_variaciones WHERE producto_id = ? ORDER BY cantidad_rosas ASC");
    $stmtVar->execute([$id]);
    $variaciones = $stmtVar->fetchAll(PDO::FETCH_OBJ);

    // DETERMINAR SI ES RAMO PARA TEXTOS DINÁMICOS
    $esRamo = (stripos($producto->categoria_nombre, 'Ramo') !== false);

    // Automatización de variaciones si la DB está vacía
    if (empty($variaciones)) {
        if ($esRamo) {
            $variaciones = [
                (object)['cantidad_rosas' => 6, 'precio_adicional' => 0],
                (object)['cantidad_rosas' => 12, 'precio_adicional' => 15],
                (object)['cantidad_rosas' => 24, 'precio_adicional' => 35]
            ];
        } else {
            $variaciones = [
                (object)['cantidad_rosas' => 10, 'precio_adicional' => 0],
                (object)['cantidad_rosas' => 20, 'precio_adicional' => 20],
                (object)['cantidad_rosas' => 30, 'precio_adicional' => 45]
            ];
        }
    }

    // 4. Traer extras (vinculados al producto)
    $stmtExt = $pdo->prepare("SELECT e.* FROM extras e 
                              JOIN producto_extras pe ON e.id = pe.extra_id 
                              WHERE pe.producto_id = ?");
    $stmtExt->execute([$id]);
    $extras = $stmtExt->fetchAll(PDO::FETCH_OBJ);

    // 5. Traer colores disponibles
    $stmtCol = $pdo->prepare("SELECT c.* FROM colores c 
                              JOIN producto_colores pc ON c.id = pc.color_id 
                              WHERE pc.producto_id = ?");
    $stmtCol->execute([$id]);
    $colores = $stmtCol->fetchAll(PDO::FETCH_OBJ);

    // Precios iniciales para el renderizado
    $precioBase = (float)$producto->precio_base;
    $precioInicial = $precioBase + (float)$variaciones[0]->precio_adicional;

} catch (PDOException $e) {
    die("Error en el sistema de catálogo.");
}
?>

<style>
    /* Estilos Premium Everbloom */
    .glass-dark {
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.9) 0%, rgba(30, 41, 59, 0.8) 100%);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.05);
    }

    .fade-up {
        animation: fadeUp 0.8s ease-out forwards;
    }

    @keyframes fadeUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .color-ring {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
    }

    input[type="radio"]:checked + .color-ring {
        box-shadow: 0 0 0 4px #0f172a, 0 0 0 7px #d946ef;
        transform: scale(1.15);
    }

    .custom-scrollbar::-webkit-scrollbar { width: 5px; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #d946ef; border-radius: 10px; }
</style>

<main class="bg-white dark:bg-slate-950 min-h-screen text-slate-900 dark:text-slate-200 font-sans pb-24">
    <div class="container mx-auto px-6 py-12 lg:py-20">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-start">
            
            <!-- COLUMNA IZQUIERDA: GALERÍA/IMAGEN -->
            <div class="lg:sticky lg:top-32 fade-up">
                <div class="relative group">
                    <div class="absolute -inset-10 bg-brand-primary/10 blur-[100px] rounded-full opacity-50"></div>
                    
                    <div class="relative bg-slate-100 dark:bg-slate-900 rounded-[3.5rem] p-4 shadow-2xl border border-slate-200 dark:border-white/5 overflow-hidden">
                        <img id="main-product-image" 
                             src="public/img/productos/<?= $producto->id ?>/<?= $producto->imagen_principal ?: '1.webp' ?>" 
                             class="w-full aspect-[4/5] object-cover rounded-[3rem] transition duration-1000 group-hover:scale-105" 
                             alt="<?= htmlspecialchars($producto->nombre) ?>"
                             onerror="this.src='https://placehold.co/600x800?text=Everbloom+Sameth'">
                    </div>
                    
                    <div class="absolute -bottom-6 -right-6 bg-white text-slate-950 p-6 rounded-3xl shadow-2xl rotate-12 hidden md:block border-4 border-slate-950">
                        <p class="text-[10px] font-black uppercase tracking-tighter leading-none">Detalle Eterno</p>
                        <p class="font-serif italic text-lg text-brand-primary">Everbloom®</p>
                    </div>
                </div>
            </div>
            
            <!-- COLUMNA DERECHA: CONFIGURADOR -->
            <div class="space-y-12 fade-up" style="animation-delay: 0.2s;">
                <section>
                    <nav class="flex items-center space-x-2 text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-6">
                        <a href="home" class="hover:text-brand-primary transition-colors">Inicio</a>
                        <span>/</span>
                        <span class="text-brand-primary"><?= $producto->categoria_nombre ?></span>
                    </nav>
                    
                    <h1 class="text-5xl md:text-6xl font-serif font-bold text-slate-900 dark:text-white mb-6 leading-tight">
                        <?= $producto->nombre ?>
                    </h1>
                    
                    <div class="relative pl-8 border-l-2 border-brand-primary/30">
                        <p class="text-slate-600 dark:text-slate-400 leading-relaxed text-lg font-light italic">
                            "<?= $producto->descripcion ?>"
                        </p>
                    </div>
                </section>

                <!-- 1. TAMAÑO/CANTIDAD -->
                <section class="space-y-6">
                    <h3 class="text-[11px] font-black text-slate-900 dark:text-white uppercase tracking-[0.3em] flex items-center gap-3">
                        <span class="w-8 h-[1px] bg-brand-primary"></span>
                        1. <?= $esRamo ? 'Cantidad de Rosas' : 'Dimensiones del Regalo' ?>
                    </h3>
                    <div class="grid grid-cols-3 gap-4">
                        <?php foreach($variaciones as $index => $v): ?>
                        <label class="relative cursor-pointer group">
                            <input type="radio" name="size" value="<?= $v->cantidad_rosas ?>" 
                                   data-price="<?= $v->precio_adicional ?>" 
                                   class="peer hidden" <?= $index === 0 ? 'checked' : '' ?>>
                            <div class="p-6 bg-slate-100 dark:bg-slate-900/50 border border-slate-200 dark:border-white/5 rounded-[2.5rem] text-center transition-all duration-300 peer-checked:border-brand-primary peer-checked:bg-brand-primary/10 peer-checked:ring-1 peer-checked:ring-brand-primary group-hover:border-white/20">
                                <span class="block text-3xl font-serif font-bold text-slate-900 dark:text-white mb-1"><?= $v->cantidad_rosas ?></span>
                                <span class="text-[9px] text-slate-500 uppercase font-black tracking-widest"><?= $esRamo ? 'Rosas' : 'cm' ?></span>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- 2. COLOR DEL SATÍN -->
                <section class="space-y-6">
                    <div class="flex justify-between items-center">
                        <h3 class="text-[11px] font-black text-slate-900 dark:text-white uppercase tracking-[0.3em] flex items-center gap-3">
                            <span class="w-8 h-[1px] bg-brand-primary"></span>
                            2. Tono del Satín
                        </h3>
                        <span id="selected-color-name" class="text-[10px] font-bold text-brand-primary uppercase tracking-widest bg-brand-primary/10 px-3 py-1 rounded-lg">
                            <?= !empty($colores) ? $colores[0]->nombre : 'Personalizado' ?>
                        </span>
                    </div>
                    
                    <div class="flex flex-wrap gap-6 p-7 bg-slate-100 dark:bg-slate-900/30 rounded-[3rem] border border-slate-200 dark:border-white/5">
                        <?php foreach($colores as $index => $c): ?>
                        <label class="relative cursor-pointer">
                            <input type="radio" name="color" value="<?= $c->nombre ?>" 
                                   class="peer hidden" <?= $index === 0 ? 'checked' : '' ?>
                                   onchange="updateColorDisplay('<?= $c->nombre ?>')">
                            <div class="color-ring w-12 h-12 rounded-full border-2 border-white/10 shadow-lg"
                                 style="background-color: <?= $c->codigo_hex ?>;">
                            </div>
                        </label>
                        <?php endforeach; ?>
                        
                        <label class="relative cursor-pointer">
                            <input type="radio" name="color" value="Especial" class="peer hidden" onchange="toggleCustomColor(true)">
                            <div class="bg-white dark:bg-slate-900 border-slate-200 dark:border-white/10 text-slate-900 dark:text-white w-12 h-12 rounded-full border-2 border-dashed border-slate-700 flex items-center justify-center text-slate-500 hover:border-brand-primary hover:text-brand-primary transition-all">
                                <span class="text-xl">+</span>
                            </div>
                        </label>
                    </div>
                    
                    <div id="custom-color-container" class="hidden animate-fade-in">
                        <input type="text" id="custom-color-input" placeholder="¿Qué color o combinación deseas?" 
                               class="w-full px-6 py-4 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-white/10 focus:border-brand-primary/50 outline-none transition-all text-sm text-slate-900 dark:text-white italic">
                    </div>
                </section>

                <!-- 3. COMPLEMENTOS EXTRAS -->
                <section class="space-y-6">
                    <h3 class="text-[11px] font-black text-slate-900 dark:text-white uppercase tracking-[0.3em] flex items-center gap-3">
                        <span class="w-8 h-[1px] bg-brand-primary"></span>
                        3. Añadir Extras
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php foreach($extras as $e): ?>
                        <label class="flex items-center p-5 rounded-3xl cursor-pointer border border-slate-200 dark:border-white/5 bg-slate-100 dark:bg-slate-900/30 hover:bg-slate-100 dark:bg-slate-900 hover:border-brand-primary/30 transition-all group">
                            <input type="checkbox" class="extra-item w-5 h-5 rounded border-slate-700 text-brand-primary focus:ring-brand-primary bg-slate-800" 
                                   data-price="<?= $e->precio ?>" data-name="<?= $e->nombre ?>">
                            <div class="ml-4 flex-1">
                                <span class="block text-sm font-bold text-slate-300 group-hover:text-slate-900 dark:text-white"><?= $e->nombre ?></span>
                                <span class="text-[10px] text-brand-primary font-bold tracking-widest">+ S/ <?= number_format($e->precio, 2) ?></span>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- TOTAL Y BOTÓN WHATSAPP -->
                <div class="bg-slate-100 dark:bg-slate-900/30 shadow-xl dark:shadow-3xl border border-slate-200 dark:border-white/10 rounded-[3rem] p-8 text-center">
                    <div class="relative z-10 flex flex-col md:flex-row justify-between items-center gap-10">
                        <div class="text-center md:text-left">
                            <p class="text-slate-900 dark:text-white text-[10px] uppercase font-black tracking-[0.3em] mb-3">Inversión Final</p>
                            <div class="flex items-baseline justify-center md:justify-start gap-2">
                                <span class="text-2xl font-light text-brand-primary italic">S/</span>
                                <span id="final-price" class="text-7xl font-serif font-bold tracking-tighter text-slate-900 dark:text-white">
                                    <?= number_format($precioInicial, 2) ?>
                                </span>
                            </div>
                        </div>

                        <button id="whatsapp-btn" class="w-full md:w-auto px-12 py-7 bg-brand-primary hover:text-brand-dark text-slate-900 dark:text-white rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] shadow-[0_20px_60px_rgba(217,70,239,0.3)] transition-all duration-500 active:scale-95 group flex items-center justify-center gap-4">
                            <i class="fab fa-whatsapp text-xl"></i>
                            <span>Hacer mi Pedido</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    // Inyección de datos PHP a JS para el calculador
    window.currentProductName = "<?= addslashes($producto->nombre) ?>";
    window.basePrice = <?= $precioBase ?>;
    window.esRamo = <?= $esRamo ? 'true' : 'false' ?>;

    function updateColorDisplay(name) {
        document.getElementById('selected-color-name').innerText = name;
        toggleCustomColor(false);
    }

    function toggleCustomColor(show) {
        const container = document.getElementById('custom-color-container');
        const input = document.getElementById('custom-color-input');
        if(show) {
            container.classList.remove('hidden');
            document.getElementById('selected-color-name').innerText = 'Personalizado';
            input.focus();
        } else {
            container.classList.add('hidden');
        }
    }
</script>

<!-- Scripts externos -->
<script src="public/js/calculator.js"></script>

<?php include 'includes/footer.php'; ?>