<?php include 'includes/header.php'; ?>

<main class="bg-[#FCFCFC] text-slate-900 pb-32">
    <header class="relative overflow-hidden bg-slate-950 text-white py-24 md:py-40">

    <!-- Fondo decorativo -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 blur-[120px] rounded-full -mr-48 -mt-48"></div>
        <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>

        <div class="container mx-auto px-6">
            <span class="text-brand-primary uppercase tracking-[0.5em] text-[10px] font-bold mb-4 block">Asistencia</span>
            <h1 class="text-5xl md:text-7xl font-serif tracking-tighter">Resolviendo <br><span class="italic text-brand-primary">tus dudas</span></h1>
            <p class="mt-8 text-slate-500 max-w-lg font-light leading-relaxed">
                Todo lo que necesitas saber sobre nuestras rosas eternas de satín, envíos y el proceso artesanal detrás de cada pétalo.
            </p>
        </div>
    </header>

    <section class="container mx-auto px-6 mt-20">
        <div class="max-w-3xl mx-auto space-y-4">
            
            <?php
            $faqs = [
                [
                    'q' => '¿De qué material están hechas las rosas?',
                    'a' => 'Nuestras rosas son piezas de alta costura artesanal. Utilizamos listón de satín premium de doble cara, lo que les otorga un brillo elegante y una estructura firme que no se deforma con el tiempo.'
                ],
                [
                    'q' => '¿Cuánto tiempo duran realmente?',
                    'a' => 'A diferencia de las rosas naturales o preservadas, nuestras rosas Everbloom son eternas. Al ser de tela técnica, no se marchitan, no se oxidan y mantienen su color original por años con cuidados mínimos.'
                ],
                [
                    'q' => '¿Realizan envíos a provincias?',
                    'a' => 'Sí, llegamos a todo el Perú. En Lima utilizamos movilidad propia para garantizar que el ramo llegue impecable, y para provincias enviamos vía Olva Courier o Shalom en empaques reforzados de alta seguridad.'
                ],
                [
                    'q' => '¿Puedo personalizar los colores?',
                    'a' => '¡Absolutamente! Contamos con una paleta de más de 20 colores de satín. Puedes elegir el color de los pétalos, el estilo del papel coreano y el mensaje personalizado que grabamos con tecnología Silhouette Cameo.'
                ],
                [
                    'q' => '¿Con cuánta anticipación debo hacer mi pedido?',
                    'a' => 'Al ser un trabajo 100% manual, recomendamos realizar el pedido con 3 a 5 días de anticipación. Sin embargo, si tienes una emergencia, escríbenos al WhatsApp para revisar disponibilidad de stock inmediato.'
                ]
            ];
            ?>

            <?php foreach($faqs as $index => $faq): ?>
            <div class="group border-b border-slate-100 last:border-0">
                <button class="w-full py-8 flex justify-between items-center text-left focus:outline-none faq-trigger">
                    <span class="text-lg md:text-xl font-serif text-slate-800 group-hover:text-brand-primary transition-colors">
                        <?= $faq['q'] ?>
                    </span>
                    <span class="ml-4 flex-shrink-0 w-8 h-8 rounded-full border border-slate-200 flex items-center justify-center group-hover:border-brand-primary transition-all duration-500 transform icon-arrow">
                        <i class="fas fa-chevron-down text-[10px] text-slate-400 group-hover:text-brand-primary"></i>
                    </span>
                </button>
                <div class="max-h-0 overflow-hidden transition-all duration-700 ease-in-out faq-content">
                    <p class="pb-8 text-slate-500 font-light leading-relaxed max-w-2xl text-sm">
                        <?= $faq['a'] ?>
                    </p>
                </div>
            </div>
            <?php endforeach; ?>

        </div>
    </section>

    <section class="mt-32 container mx-auto px-6">
        <div class="bg-slate-50 rounded-[3rem] p-12 text-center relative overflow-hidden bg-slate-950 text-white py-24 md:py-40">
            <!-- Fondo decorativo -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 blur-[120px] rounded-full -mr-48 -mt-48"></div>
        <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>
            <h3 class="font-serif text-3xl mb-4 text-slate-100">¿Aún tienes dudas?</h3>
            <p class="text-slate-500 mb-8 font-light">Estamos disponibles en WhatsApp para asesorarte con tu elección.</p>
            <a href="https://wa.me/51951774812" target="_blank" class="inline-flex items-center gap-3 bg-slate-900 text-white px-8 py-4 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-brand-primary transition-all duration-500">
                <i class="fab fa-whatsapp text-lg"></i> Consultar Ahora
            </a>
        </div>
    </section>
</main>

<script>
    document.querySelectorAll('.faq-trigger').forEach(button => {
        button.addEventListener('click', () => {
            const content = button.nextElementSibling;
            const icon = button.querySelector('.icon-arrow');
            
            // Cerrar otros abiertos (opcional, estilo acordeón)
            document.querySelectorAll('.faq-content').forEach(other => {
                if (other !== content) {
                    other.style.maxHeight = null;
                    other.previousElementSibling.querySelector('.icon-arrow').style.transform = 'rotate(0deg)';
                }
            });

            // Toggle actual
            if (content.style.maxHeight) {
                content.style.maxHeight = null;
                icon.style.transform = 'rotate(0deg)';
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
                icon.style.transform = 'rotate(180deg)';
            }
        });
    });
</script>

<?php include 'includes/footer.php'; ?>