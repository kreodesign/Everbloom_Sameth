<?php include 'includes/header.php'; ?>

<main class="bg-[#FCFCFC] text-slate-900 pb-32">
    <header class="relative overflow-hidden bg-slate-950 text-white py-24 md:py-40">

    <!-- Fondo decorativo -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 blur-[120px] rounded-full -mr-48 -mt-48"></div>
        <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-purple-600/10 blur-[100px] rounded-full -ml-24 -mb-24"></div>

        <div class="container mx-auto px-6">
            <span class="text-brand-primary uppercase tracking-[0.5em] text-[10px] font-bold mb-4 block">Compromiso Mutuo</span>
            <h1 class="text-5xl md:text-7xl font-serif tracking-tighter">Términos & <br><span class="italic text-brand-primary">Condiciones</span></h1>
            <p class="mt-8 text-slate-400 text-sm tracking-widest uppercase">Vigentes desde: Marzo 2026</p>
            <p class="mt-4 text-slate-400 max-w-lg leading-relaxed font-light">Al acceder y utilizar Everbloom Sameth, aceptas cumplir con estos términos que rigen nuestra relación comercial. Por favor, léelos detenidamente.</p>
        </div>
    </header>

    <section class="container mx-auto px-6 mt-20">
        <div class="grid md:grid-cols-12 gap-16">
            
            <aside class="hidden md:block md:col-span-4 sticky top-32 h-fit">
                <nav class="space-y-4 border-l border-slate-100 pl-6 text-[10px] uppercase tracking-widest font-bold">
                    <a href="#pedidos" class="block text-slate-400 hover:text-brand-primary transition-colors">01. Pedidos Personalizados</a>
                    <a href="#envios" class="block text-slate-400 hover:text-brand-primary transition-colors">02. Envíos y Entregas</a>
                    <a href="#cancelaciones" class="block text-slate-400 hover:text-brand-primary transition-colors">03. Devoluciones</a>
                    <a href="#cuidados" class="block text-slate-400 hover:text-brand-primary transition-colors">04. Garantía y Cuidados</a>
                </nav>
            </aside>

            <div class="md:col-span-8 space-y-20 leading-relaxed font-light text-slate-600">
                
                <article id="pedidos" class="space-y-6">
                    <h2 class="text-3xl font-serif text-slate-900 italic">01. Naturaleza del Producto</h2>
                    <p>
                        Cada rosa en <strong>Everbloom Sameth</strong> es una pieza artesanal única hecha a mano con listón satinado de alta calidad. Al ser productos hechos bajo pedido (on-demand), el cliente acepta que pueden existir variaciones mínimas en la disposición de los pétalos, lo cual es prueba de su origen manual y no un defecto de fabricación.
                    </p>
                </article>

                <article id="envios" class="space-y-6">
                    <h2 class="text-3xl font-serif text-slate-900 italic">02. Logística y Entregas</h2>
                    <div class="space-y-4 pt-4 text-sm uppercase tracking-tight">
                        <div class="flex justify-between border-b border-slate-100 pb-2">
                            <span class="font-bold text-slate-900">Lima Metropolitana:</span>
                            <span>2 a 4 días hábiles</span>
                        </div>
                        <div class="flex justify-between border-b border-slate-100 pb-2">
                            <span class="font-bold text-slate-900">Provincias (Perú):</span>
                            <span>Vía Olva Courier / Shalom</span>
                        </div>
                    </div>
                    <p class="pt-4">
                        Es responsabilidad del cliente proporcionar una dirección exacta y un número de contacto activo. Everbloom no se hace responsable por retrasos causados por información incorrecta o ausencia del receptor.
                    </p>
                </article>

                <article id="cancelaciones" class="space-y-6">
                    <h2 class="text-3xl font-serif text-slate-900 italic">03. Política de No Devolución</h2>
                    <p>
                        Debido a la naturaleza <strong>estrictamente personalizada</strong> de nuestras rosas (colores elegidos, cantidades específicas y dedicatorias grabadas con Silhouette Cameo), <strong>no se aceptan devoluciones ni cambios</strong> una vez que el proceso de fabricación ha comenzado. 
                    </p>
                    <p class="bg-rose-50 p-6 rounded-2xl text-slate-800 text-sm italic">
                        * Si el producto llega dañado por el transporte, el cliente tiene un plazo máximo de 12 horas tras la recepción para enviar evidencia fotográfica vía WhatsApp y coordinar una solución.
                    </p>
                </article>

                <article id="cuidados" class="space-y-6">
                    <h2 class="text-3xl font-serif text-slate-900 italic">04. Garantía de Eternidad</h2>
                    <p>
                        Nuestras rosas están diseñadas para durar indefinidamente si se siguen estos cuidados básicos:
                    </p>
                    <ul class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-bold uppercase tracking-widest text-slate-500">
                        <li class="flex items-center gap-2"><i class="fas fa-sun text-brand-primary"></i> Evitar sol directo prolongado</li>
                        <li class="flex items-center gap-2"><i class="fas fa-tint-slash text-brand-primary"></i> No mojar ni humedecer</li>
                        <li class="flex items-center gap-2"><i class="fas fa-wind text-brand-primary"></i> Limpiar polvo con aire frío</li>
                        <li class="flex items-center gap-2"><i class="fas fa-hand-sparkles text-brand-primary"></i> Manipular por el tallo</li>
                    </ul>
                </article>

                <div class="pt-20 border-t border-slate-100">
                    <p class="text-center font-serif italic text-2xl text-slate-400">
                        Gracias por permitirnos crear algo eterno para ti.
                    </p>
                </div>

            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>