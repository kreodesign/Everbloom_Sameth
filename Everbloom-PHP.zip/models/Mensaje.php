<?php
// models/Mensaje.php

class Mensaje {
    public $id;
    public $nombre;
    public $telefono;
    public $motivo;
    public $mensaje;
    public $fecha;

    public function __construct($args = []) {
        $this->id = $args['id'] ?? null;
        $this->nombre = $args['nombre'] ?? '';
        $this->telefono = $args['telefono'] ?? '';
        $this->motivo = $args['motivo'] ?? '';
        $this->mensaje = $args['mensaje'] ?? '';
        $this->fecha = date('Y-m-d H:i:s');
    }
}