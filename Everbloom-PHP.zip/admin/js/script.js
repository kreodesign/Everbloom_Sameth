/**
 * Everbloom Admin - Core Engine
 * Maneja Inventario, Galería, AJAX y UI Dinámica
 */

const EverbloomAdmin = (() => {
    // --- CONFIGURACIÓN Y SELECTORES ---
    const ui = {
        formAdd: document.getElementById('formAdd'),
        formEdit: document.getElementById('formEdit'),
        modalAdd: new bootstrap.Modal(document.getElementById('modalAdd')),
        modalEdit: document.getElementById('modalEdit') ? new bootstrap.Modal(document.getElementById('modalEdit')) : null,
        dropzone: document.getElementById('dzAdd'),
        galleryPreview: document.getElementById('prevGalAdd')
    };

    // --- INICIALIZACIÓN ---
    const init = () => {
        setupEventListeners();
        setupDragAndDrop();
        console.log("Everbloom Admin Engine: Ready");
    };

    const setupEventListeners = () => {
        // Enviar formulario de nuevo producto
        if (ui.formAdd) {
            ui.formAdd.addEventListener('submit', (e) => handleFormSubmit(e, ui.modalAdd));
        }

        // Delegación de eventos para botones dinámicos (Futuras funciones)
        document.addEventListener('click', (e) => {
            if (e.target.closest('.btn-delete-product')) {
                const id = e.target.closest('.btn-delete-product').dataset.id;
                deleteProduct(id);
            }
        });
    };

    // --- MANEJO DE AJAX (POST) ---
    const handleFormSubmit = async (e, modalInstance) => {
        e.preventDefault();
        const form = e.target;
        const btn = form.querySelector('button[type="submit"]');
        const originalHTML = btn.innerHTML;

        // UI State: Cargando
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Procesando...';

        try {
            const formData = new FormData(form);
            const response = await fetch(window.location.href, {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' } // Esta cabecera es la que detecta el PHP arriba
            });

            const result = await response.json();

            if (result.status === 'success') {
                notify('Operación exitosa', 'success');
                modalInstance.hide();
                setTimeout(() => location.reload(), 1000); // Recarga suave para actualizar tabla
            } else {
                notify(result.message || 'Error en el servidor', 'danger');
            }
        } catch (error) {
            notify('Error de conexión o de red', 'danger');
            console.error(error);
        } finally {
            btn.disabled = false;
            btn.innerHTML = originalHTML;
        }
    };

    // --- LÓGICA DE DRAG & DROP ---
    const setupDragAndDrop = () => {
        if (!ui.dropzone) return;

        const input = ui.dropzone.querySelector('input[type="file"]');

        ui.dropzone.onclick = () => input.click();

        ui.dropzone.ondragover = (e) => {
            e.preventDefault();
            ui.dropzone.classList.add('dz-dragover');
        };

        ui.dropzone.ondragleave = () => ui.dropzone.classList.remove('dz-dragover');

        ui.dropzone.ondrop = (e) => {
            e.preventDefault();
            ui.dropzone.classList.remove('dz-dragover');
            input.files = e.dataTransfer.files;
            previewGallery(input.files);
        };

        input.onchange = () => previewGallery(input.files);
    };

    const previewGallery = (files) => {
        if (!ui.galleryPreview) return;
        ui.galleryPreview.innerHTML = '';
        
        Array.from(files).forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const div = document.createElement('div');
                div.className = 'gallery-item shadow-sm position-relative';
                div.innerHTML = `<img src="${e.target.result}" class="rounded w-100 h-100 object-fit-cover">`;
                ui.galleryPreview.appendChild(div);
            };
            reader.readAsDataURL(file);
        });
    };

    // --- ELIMINACIÓN DE PRODUCTO ---
    const deleteProduct = async (id) => {
        if (!confirm('¿Deseas eliminar este producto permanentemente?')) return;

        const fd = new FormData();
        fd.append('action', 'delete_product');
        fd.append('id', id);

        try {
            // Dentro de admin/js/script.js -> deleteProduct
            const res = await fetch(window.location.href, { // Cambiado de 'index.php' a window.location.href
                method: 'POST',
                body: fd,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            const data = await res.json();
            
            if (data.status === 'success') {
                document.getElementById(`row-${id}`).classList.add('fade-out');
                setTimeout(() => document.getElementById(`row-${id}`).remove(), 500);
                notify('Producto eliminado', 'info');
            }
        } catch (e) {
            notify('Error al eliminar', 'danger');
        }
    };

    // --- UTILIDADES (NOTIFICACIONES) ---
    const notify = (msg, type = 'success') => {
        // Aquí puedes integrar librerías como SweetAlert2 o un Toast simple de Bootstrap
        alert(`${type.toUpperCase()}: ${msg}`);
    };

    // --- PUBLIC API (Para llamar desde el HTML si es necesario) ---
    return {
        init,
        deleteProduct,
        // Dentro de EverbloomAdmin en admin/js/script.js
        openEditModal: (p) => {
            // 1. Llenamos los campos de la modal con los datos recibidos
            document.getElementById('edit_id').value = p.id;
            document.getElementById('edit_nombre').value = p.nombre;
            document.getElementById('edit_precio').value = p.precio_base;
            document.getElementById('edit_categoria').value = p.categoria_id;
            document.getElementById('edit_descripcion').value = p.descripcion;

            // 2. Mostramos la modal (asegúrate de que ui.modalEdit esté inicializado arriba)
            const modal = new bootstrap.Modal(document.getElementById('modalEdit'));
            modal.show();

            // 3. Escuchar el envío del formulario de edición (si no se ha hecho antes)
            const formEdit = document.getElementById('formEdit');
            formEdit.onsubmit = async (e) => {
                e.preventDefault();
                const fd = new FormData(formEdit);
                
                // Usamos la misma lógica de envío que en handleFormSubmit
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: fd,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                const res = await response.json();
                if(res.status === 'success') location.reload();
            };
        }
    };
})();

// Iniciar al cargar el DOM
document.addEventListener('DOMContentLoaded', EverbloomAdmin.init);