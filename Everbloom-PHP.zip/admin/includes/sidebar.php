<?php
/**
 * Everbloom Admin - Sidebar Modular
 * Ubicación: /admin/includes/sidebar.php
 */
$current_view = $_GET['view'] ?? 'dashboard';
?>
<!-- Sidebar -->
<div class="sidebar p-4 d-none d-md-block" style="width: 280px; min-height: 100vh;">
    <div class="d-flex align-items-center mb-5 gap-2 px-2">
        <i class="fas fa-seedling fs-4" style="color: var(--brand-primary);"></i>
        <span class="fw-bold fs-4 text-white">Everbloom</span>
    </div>
    
    <nav class="nav flex-column">
        <a href="index.php?view=dashboard" class="nav-link <?= ($current_view == 'dashboard') ? 'active' : '' ?>">
            <i class="fas fa-box me-2"></i> Inventario
        </a>
        
        <a href="index.php?view=mensajes" class="nav-link <?= ($current_view == 'mensajes') ? 'active' : '' ?>">
            <i class="fas fa-envelope me-2"></i> Mensajes
        </a>

        <a href="index.php?view=categorias" class="nav-link <?= ($current_view == 'categorias') ? 'active' : '' ?>">
            <i class="fas fa-tags me-2"></i> Categorías
        </a>
        
        <hr class="text-secondary opacity-25 my-4">
        
        <a href="/" class="nav-link" target="_blank">
            <i class="fas fa-store me-2"></i> Ver Tienda
        </a>
        
        <a href="/logout" class="nav-link text-danger mt-5">
            <i class="fas fa-sign-out-alt me-2"></i> Cerrar Sesión
        </a>
    </nav>
</div>

<!-- Contenedor Principal de Contenido (Se cierra en el footer) -->
<div class="main-content flex-grow-1 p-4 p-md-5">