<?php
/**
 * Everbloom Admin - Header Modular
 * Ubicación: /admin/includes/header.php
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Everbloom Admin | Gestión de Catálogo</title>
    
    <!-- Fuentes y Estilos Externos -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <!-- Estilos Personalizados del Panel -->
    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="bg-light">

<div class="container-fluid p-0">
    <div class="d-flex flex-column flex-md-row">