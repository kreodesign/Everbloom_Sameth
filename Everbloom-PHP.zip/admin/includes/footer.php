<?php
/**
 * Everbloom Admin - Footer Modular
 * Ubicación: /admin/includes/footer.php
 */
?>
    </div> <!-- Cierre de .main-content -->
  </div> <!-- Cierre de .d-flex -->
</div> <!-- Cierre de .container-fluid -->

<!-- Scripts de Funcionalidad -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>

<!-- Inicialización de componentes dinámicos de Bootstrap (Tooltips/Popovers) -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
    });
</script>

</body>
</html>