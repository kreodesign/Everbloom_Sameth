<?php
/**
 * Everbloom Admin - Vista de Inventario (Dashboard)
 * Ubicación: /admin/dashboard.php
 * Nota: Este archivo es cargado entre el sidebar.php y el footer.php
 */
?>

<!-- Encabezado de la Sección -->
<header class="d-flex justify-content-between align-items-center mb-5">
    <div>
        <h2 class="fw-bold mb-1">Gestión de Catálogo</h2>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item text-muted">Admin</li>
                <li class="breadcrumb-item active" aria-current="page">Inventario</li>
            </ol>
        </nav>
    </div>
    <button class="btn btn-everbloom shadow-sm" data-bs-toggle="modal" data-bs-target="#modalAdd">
        <i class="fas fa-plus me-2"></i>Nuevo Producto
    </button>
</header>

<!-- Tarjetas de Métricas Rápidas -->
<div class="row g-4 mb-5">
    <div class="col-md-4">
        <div class="card p-4 border-0 shadow-sm h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="icon-box bg-light-pink text-pink p-3 rounded-4">
                    <i class="fas fa-box fs-4"></i>
                </div>
                <div>
                    <small class="text-muted fw-bold d-block">TOTAL PRODUCTOS</small>
                    <h3 class="fw-bold mb-0"><?= count($productos) ?></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-4 border-0 shadow-sm h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="icon-box bg-light-blue text-primary p-3 rounded-4">
                    <i class="fas fa-envelope fs-4"></i>
                </div>
                <div>
                    <small class="text-muted fw-bold d-block">MENSAJES DE HOY</small>
                    <h3 class="fw-bold mb-0 text-primary"><?= $stats['hoy'] ?></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-4 border-0 shadow-sm h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="icon-box bg-light-green text-success p-3 rounded-4">
                    <i class="fas fa-check-circle fs-4"></i>
                </div>
                <div>
                    <small class="text-muted fw-bold d-block">ESTADO SISTEMA</small>
                    <h3 class="fw-bold mb-0 text-success">Activo</h3>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tabla Principal -->
<div class="card border-0 shadow-sm overflow-hidden">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="ps-4" style="width: 80px;">IMG</th>
                    <th>DETALLES DEL PRODUCTO</th>
                    <th>CATEGORÍA</th>
                    <th>PRECIO BASE</th>
                    <th class="text-end pe-4">ACCIONES</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($productos as $p): ?>
                <tr id="row-<?= $p->id ?>">
                    <td class="ps-4">
                        <img src="/public/img/productos/<?= $p->id ?>/1.webp" 
                             class="rounded-3 border shadow-sm" 
                             style="width: 50px; height: 50px; object-fit: cover;"
                             onerror="this.src='https://placehold.co/100x100?text=S/I'">
                    </td>
                    <td>
                        <div class="fw-bold text-dark"><?= htmlspecialchars($p->nombre) ?></div>
                        <small class="text-muted">ID: #<?= str_pad($p->id, 4, "0", STR_PAD_LEFT) ?></small>
                    </td>
                    <td>
                        <span class="badge bg-light text-secondary border px-3 py-2">
                            <?= $p->cat_nombre ?>
                        </span>
                    </td>
                    <td>
                        <span class="fw-bold text-dark">S/ <?= number_format($p->precio_base, 2) ?></span>
                    </td>
                    <td class="text-end pe-4">
                        <div class="btn-group shadow-sm">
                            <button class="btn btn-sm btn-white border" 
                                    onclick='EverbloomAdmin.openEditModal(<?= json_encode($p) ?>)' 
                                    title="Editar">
                                <i class="fas fa-edit text-primary"></i>
                            </button>
                            <button class="btn btn-sm btn-white border btn-delete-product" data-id="<?= $p->id ?>" title="Eliminar">
                                <i class="fas fa-trash text-danger"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($productos)): ?>
                <tr>
                    <td colspan="5" class="text-center py-5 text-muted">
                        <i class="fas fa-box-open d-block fs-1 mb-3 opacity-25"></i>
                        No hay productos registrados aún.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Incluimos la Modal de Agregar (También podrías modularizarla si quieres) -->
<?php include 'modals/modal_add_product.php'; // Modal para agregar producto ?>
<?php include 'modals/modal_edit_product.php'; // Modal para editar producto, cargada al final para no interferir con el flujo de la tabla ?>