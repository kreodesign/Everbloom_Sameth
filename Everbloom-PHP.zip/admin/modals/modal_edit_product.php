<?php
/**
 * Everbloom Admin - Modal Editar Producto
 * Ubicación: /admin/modals/modal_edit_product.php
 */
?>
<div class="modal fade" id="modalEdit" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form id="formEdit" class="modal-content border-0 shadow-lg" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit_product">
            <input type="hidden" name="id" id="edit_id">
            
            <div class="modal-header border-0 p-4 pb-0">
                <h4 class="fw-bold">Editar Producto</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body p-4">
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label small fw-bold">Nombre</label>
                        <input type="text" name="nombre" id="edit_nombre" class="form-control form-control-lg" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">Precio (S/)</label>
                        <input type="number" step="0.01" name="precio_base" id="edit_precio" class="form-control form-control-lg" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Categoría</label>
                        <select name="categoria_id" id="edit_categoria" class="form-select form-select-lg">
                            <?php foreach($categorias as $c): ?>
                                <option value="<?= $c->id ?>"><?= htmlspecialchars($c->nombre) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Descripción</label>
                        <textarea name="description" id="edit_descripcion" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Cambiar Foto Principal (Opcional)</label>
                        <input type="file" name="imagen_archivo" class="form-control" accept="image/*">
                    </div>
                </div>
            </div>

            <div class="modal-footer border-0 p-4 pt-0">
                <button type="button" class="btn btn-light fw-bold" data-bs-dismiss="modal">Cerrar</button>
                <button type="submit" class="btn btn-everbloom px-5">ACTUALIZAR CAMBIOS</button>
            </div>
        </form>
    </div>
</div>