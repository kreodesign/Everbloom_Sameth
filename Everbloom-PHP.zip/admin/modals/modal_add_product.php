<?php
/**
 * Everbloom Admin - Modal Agregar Producto
 * Ubicación: /admin/modals/modal_add_product.php
 */
?>
<div class="modal fade" id="modalAdd" tabindex="-1" aria-labelledby="modalAddLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form id="formAdd" class="modal-content border-0 shadow-lg" enctype="multipart/form-data">
            <!-- Acción para el Controlador -->
            <input type="hidden" name="action" value="add_product">
            
            <div class="modal-header border-0 p-4 pb-0">
                <h4 class="fw-bold" id="modalAddLabel">Crear Nuevo Arreglo</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
                <div class="row g-3">
                    <!-- Nombre y Precio -->
                    <div class="col-md-8">
                        <label class="form-label small fw-bold text-uppercase">Nombre del Producto</label>
                        <input type="text" name="nombre" class="form-control form-control-lg" placeholder="Ej. Ramo Eterno de 12 Rosas" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-uppercase">Precio (S/)</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light border-end-0">S/</span>
                            <input type="number" step="0.01" name="precio_base" class="form-control border-start-0" placeholder="0.00" required>
                        </div>
                    </div>

                    <!-- Categoría -->
                    <div class="col-12">
                        <label class="form-label small fw-bold text-uppercase">Categoría del Catálogo</label>
                        <select name="categoria_id" class="form-select form-select-lg" required>
                            <option value="" selected disabled>Selecciona una categoría...</option>
                            <?php foreach($categorias as $c): ?>
                                <option value="<?= $c->id ?>"><?= htmlspecialchars($c->nombre) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Descripción -->
                    <div class="col-12">
                        <label class="form-label small fw-bold text-uppercase">Descripción / Detalles</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Describe los materiales, colores del listón y dimensiones..."></textarea>
                    </div>

                    <!-- Imagen Principal -->
                    <div class="col-12">
                        <label class="form-label small fw-bold text-uppercase">Foto de Portada (Principal)</label>
                        <div class="input-group">
                            <input type="file" name="imagen_archivo" class="form-control" accept="image/*" required>
                            <span class="input-group-text bg-light"><i class="fas fa-image text-muted"></i></span>
                        </div>
                        <div class="form-text text-pink-500">Se convertirá automáticamente a formato .webp optimizado.</div>
                    </div>

                    <!-- Galería con Drag & Drop -->
                    <div class="col-12 mt-3">
                        <label class="form-label small fw-bold text-uppercase">Fotos Adicionales (Galería)</label>
                        <div class="dropzone" id="dzAdd">
                            <div class="dz-message">
                                <i class="fas fa-cloud-upload-alt fs-1 text-muted mb-2"></i>
                                <p class="mb-0 fw-bold">Arrastra imágenes aquí</p>
                                <span class="small text-muted">o haz clic para seleccionar (Máx. 5 fotos)</span>
                            </div>
                            <input type="file" name="galeria[]" id="inGalAdd" multiple accept="image/*" class="d-none">
                        </div>
                        <!-- Contenedor para previsualizar las fotos seleccionadas -->
                        <div id="prevGalAdd" class="gallery-container mt-3"></div>
                    </div>
                </div>
            </div>

            <div class="modal-footer border-0 p-4 pt-0">
                <button type="button" class="btn btn-light fw-bold px-4" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-everbloom px-5 shadow-sm">
                    <i class="fas fa-save me-2"></i>GUARDAR PRODUCTO
                </button>
            </div>
        </form>
    </div>
</div>