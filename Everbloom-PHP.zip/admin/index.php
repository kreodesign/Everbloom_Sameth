<?php
/**
 * Everbloom Admin - Front Controller (Enrutador Maestro)
 * Ubicación: /admin/index.php
 * * Este archivo centraliza la seguridad, la lógica de datos y el ensamblaje visual.
 */

// 1. Carga de dependencias
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../controllers/AdminController.php';

// 2. Control de Sesión y Seguridad
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirigir al login si no hay sesión activa
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location: /login');
    exit;
}

// 3. Inicialización del Controlador y Variables de Ruta
$admin = new AdminController();
$view = $_GET['view'] ?? 'dashboard';

/**
 * 4. DETECCIÓN DE PETICIÓN AJAX (CRÍTICO)
 * Esto evita que el HTML del menú se mezcle con las respuestas JSON,
 * eliminando el error de "Danger: error de conexión".
 */
$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if ($isAjax) {
    // Si es una petición de datos (POST/AJAX), procesamos y cortamos la ejecución.
    $admin->index(); 
    exit; 
}

/**
 * 5. ENSAMBLAJE VISUAL MODULAR
 * Solo se ejecuta si el usuario está navegando normalmente (Petición GET).
 */

// A. Parte Superior: Meta tags, CSS y fuentes.
include 'includes/header.php';

// B. Navegación: Menú lateral fijo.
include 'includes/sidebar.php';

// C. Cuerpo Dinámico: El contenido cambia según el parámetro 'view'.
echo '<main class="content-wrapper">'; // Contenedor opcional para ajustes finos de layout
try {
    switch ($view) {
        case 'dashboard':
            // Carga la lista de productos y estadísticas
            $admin->index(); 
            break;

        case 'mensajes':
            // Aquí cargarás la vista de mensajes cuando la tengamos lista
            if (file_exists('views/mensajes.php')) {
                include 'views/mensajes.php';
            } else {
                echo "<h2>Sección de Mensajes en construcción</h2>";
            }
            break;

        case 'categorias':
            // Gestión de categorías de productos
            if (file_exists('views/categorias.php')) {
                include 'views/categorias.php';
            } else {
                echo "<h2>Gestión de Categorías en construcción</h2>";
            }
            break;

        default:
            // Error 404 interno del panel
            echo '
            <div class="container text-center py-5">
                <i class="fas fa-search fs-1 text-muted mb-3"></i>
                <h2 class="fw-bold">Página no encontrada</h2>
                <p class="text-muted">La sección que buscas no existe en el panel administrativo.</p>
                <a href="index.php?view=dashboard" class="btn btn-everbloom">Volver al Inventario</a>
            </div>';
            break;
    }
} catch (Exception $e) {
    // Captura errores graves para no romper la interfaz
    echo '<div class="alert alert-danger m-4 shadow-sm border-0">
            <i class="fas fa-exclamation-circle me-2"></i>
            <strong>Error de Sistema:</strong> ' . $e->getMessage() . '
          </div>';
}
echo '</main>';

// D. Parte Inferior: Cierre de etiquetas y carga de Scripts (JS).
include 'includes/footer.php';