<?php include '../includes/header.php'; ?>

<main class="container mx-auto px-4 py-12 max-w-6xl">
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-serif font-bold text-slate-900">Panel Everbloom</h1>
            <p class="text-slate-500">Gestión de Catálogo</p>
        </div>
        <a href="index.php?view=nuevo" class="bg-brand-primary text-white px-6 py-3 rounded-xl font-bold shadow-lg flex items-center gap-2">
            <span>+</span> Nuevo Producto
        </a>
    </div>

    <div class="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-slate-50 border-b border-slate-100">
                    <th class="p-6 text-xs uppercase text-slate-400 font-bold">Producto</th>
                    <th class="p-6 text-xs uppercase text-slate-400 font-bold">Precio</th>
                    <th class="p-6 text-xs uppercase text-slate-400 font-bold text-right">Acciones</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-50">
                <?php foreach ($productos as $p): ?>
                <tr>
                    <td class="p-6">
                        <div class="flex items-center gap-4">
                            <img src="../public/img/products/<?= $p['imagen'] ?>/1.png" class="w-12 h-12 rounded-lg object-cover" onerror="this.src='https://placehold.co/100x100'">
                            <span class="font-bold text-slate-700"><?= $p['nombre'] ?></span>
                        </div>
                    </td>
                    <td class="p-6 font-bold text-brand-primary">S/ <?= number_format($p['precio_base'], 2) ?></td>
                    <td class="p-6 text-right space-x-3">
                        <a href="index.php?view=eliminar&id=<?= $p['id'] ?>" class="text-red-400 hover:text-red-600" onclick="return confirm('¿Borrar producto?')">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php include '../includes/footer.php'; ?>