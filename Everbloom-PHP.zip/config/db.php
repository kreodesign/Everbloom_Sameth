<?php
// Configuración de la conexión (Valores por defecto en XAMPP/WAMP)
$host = "localhost";
$user = "root";
$pass = "";
$db   = "everbloom_db";

try {
    // Creamos la conexión usando PDO (más seguro y moderno)
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    
    // Configuramos para que lance excepciones en caso de error
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Configuramos para que devuelva los datos como objetos por defecto
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    
} catch (PDOException $e) {
    // Si hay un error, lo mostramos (en producción deberías ocultar el $e->getMessage())
    die("Error de conexión a la base de datos: " . $e->getMessage());
}
?>