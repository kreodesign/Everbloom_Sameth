-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-03-2026 a las 06:34:18
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `everbloom_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `slug` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`, `slug`) VALUES
(1, 'Ramos Eternos', 'ramos'),
(2, 'Regalos Especiales', 'regalos'),
(3, 'Materiales y DIY', 'materiales'),
(4, 'Flores Individuales', 'individuales'),
(5, 'Cajas de Ensueño', 'cajas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `colores`
--

CREATE TABLE `colores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `codigo_hex` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `colores`
--

INSERT INTO `colores` (`id`, `nombre`, `codigo_hex`) VALUES
(1, 'Rojo Pasión', '#E11D48'),
(2, 'Rosa Pastel', '#F9A8D4'),
(3, 'Azul Real', '#1E40AF'),
(4, 'Blanco Satinado', '#F8FAFC'),
(5, 'Lila Místico', '#A855F7'),
(6, 'Dorado Champagne', '#FDE047'),
(7, 'Rojo Pasión', '#E11D48'),
(8, 'Rosa Pastel', '#F9A8D4'),
(9, 'Blanco Satinado', '#F8FAFC'),
(10, 'Azul Real', '#1E40AF'),
(11, 'Lila Místico', '#A855F7'),
(12, 'Dorado Champagne', '#FDE047'),
(13, 'Negro Elegante', '#0F172A'),
(14, 'Verde Esmeralda', '#059669');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `extras`
--

CREATE TABLE `extras` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `icono` varchar(50) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `extras`
--

INSERT INTO `extras` (`id`, `nombre`, `precio`, `icono`, `activo`) VALUES
(1, 'Luces LED', 5.00, NULL, 1),
(2, 'Tarjeta Personalizada', 3.00, NULL, 1),
(3, 'Caja de Regalo', 10.00, NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes_contacto`
--

CREATE TABLE `mensajes_contacto` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `motivo` varchar(100) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mensajes_contacto`
--

INSERT INTO `mensajes_contacto` (`id`, `nombre`, `telefono`, `motivo`, `mensaje`, `fecha`) VALUES
(1, 'Hola Mundo', '123123123', 'Envios', 'qwertyuiopp', '2026-03-08 07:14:39'),
(2, 'PilimiliCT', '999999999', 'Envios', 'Hola hacen envios a tumbes', '2026-03-08 07:16:04'),
(3, 'samuel', '951774812', 'Envios', 'Holoa hacen envios a provincia?', '2026-03-09 04:59:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio_base` decimal(10,2) NOT NULL,
  `imagen_principal` varchar(255) DEFAULT NULL,
  `es_popular` tinyint(1) DEFAULT 0,
  `activo` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `categoria_id`, `nombre`, `descripcion`, `precio_base`, `imagen_principal`, `es_popular`, `activo`, `created_at`) VALUES
(1, 3, 'Amor Eterno', '6 rosas satinadas con envoltura premium. Un detalle clásico y elegante.', 20.00, '1.webp', 1, 1, '2026-03-04 23:13:09'),
(2, 3, 'Everbloom Eternity', '12 rosas satinadas con envoltura premium de larga duración.', 35.00, '1.webp', 0, 1, '2026-03-04 23:13:09'),
(3, 3, 'Noche Mística', '24 rosas, incluye luces LED y tonos profundos para una noche mágica.', 55.00, '1.webp', 0, 1, '2026-03-04 23:13:09'),
(4, 3, 'Domo de Cristal', 'Una rosa eterna encapsulada tipo Bella y Bestia en cúpula de vidrio.', 12.00, '1.webp', 0, 1, '2026-03-04 23:13:09'),
(5, 3, 'Ramo Gigante', '50 rosas de lujo para una declaración impactante e inolvidable.', 120.00, '1.webp', 0, 1, '2026-03-04 23:13:09'),
(6, 3, 'Blue Box', 'Elegante caja azul con rosas seleccionadas de acabado satinado superior.', 45.00, '1.webp', 0, 1, '2026-03-04 23:13:09'),
(7, 3, 'Ramo Rosa Pastel', 'Combinación delicada de tonos rosas para expresar ternura.', 38.00, '1.webp', 0, 1, '2026-03-04 23:13:09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_colores`
--

CREATE TABLE `producto_colores` (
  `producto_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto_colores`
--

INSERT INTO `producto_colores` (`producto_id`, `color_id`) VALUES
(1, 1),
(1, 2),
(1, 4),
(1, 5),
(2, 1),
(2, 2),
(2, 4),
(3, 1),
(3, 2),
(3, 4),
(4, 1),
(4, 2),
(4, 4),
(5, 1),
(5, 2),
(5, 4),
(6, 1),
(6, 2),
(6, 4),
(7, 1),
(7, 2),
(7, 4),
(7, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_extras`
--

CREATE TABLE `producto_extras` (
  `producto_id` int(11) NOT NULL,
  `extra_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto_extras`
--

INSERT INTO `producto_extras` (`producto_id`, `extra_id`) VALUES
(1, 1),
(1, 2),
(1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_imagenes`
--

CREATE TABLE `producto_imagenes` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `ruta` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_variaciones`
--

CREATE TABLE `producto_variaciones` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad_rosas` int(11) NOT NULL,
  `precio_adicional` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto_variaciones`
--

INSERT INTO `producto_variaciones` (`id`, `producto_id`, `cantidad_rosas`, `precio_adicional`) VALUES
(7, 1, 6, 0.00),
(8, 2, 6, 0.00),
(9, 5, 6, 0.00),
(10, 7, 6, 0.00),
(11, 1, 12, 15.00),
(12, 2, 12, 15.00),
(13, 5, 12, 15.00),
(14, 7, 12, 15.00),
(15, 1, 24, 35.00),
(16, 2, 24, 35.00),
(17, 5, 24, 35.00),
(18, 7, 24, 35.00),
(22, 3, 10, 0.00),
(23, 4, 10, 0.00),
(24, 6, 10, 0.00),
(25, 3, 20, 20.00),
(26, 4, 20, 20.00),
(27, 6, 20, 20.00),
(28, 3, 30, 45.00),
(29, 4, 30, 45.00),
(30, 6, 30, 45.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`) VALUES
(1, 'Administrador', 'admin@everbloom.com', '$2y$10$oj4op99Fr8MIVRW7O3/U6OW00KaTkFjCNHCVbj705nKCLB5sflvGG');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indices de la tabla `colores`
--
ALTER TABLE `colores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `extras`
--
ALTER TABLE `extras`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mensajes_contacto`
--
ALTER TABLE `mensajes_contacto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indices de la tabla `producto_colores`
--
ALTER TABLE `producto_colores`
  ADD PRIMARY KEY (`producto_id`,`color_id`),
  ADD KEY `color_id` (`color_id`);

--
-- Indices de la tabla `producto_extras`
--
ALTER TABLE `producto_extras`
  ADD PRIMARY KEY (`producto_id`,`extra_id`),
  ADD KEY `extra_id` (`extra_id`);

--
-- Indices de la tabla `producto_imagenes`
--
ALTER TABLE `producto_imagenes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `producto_variaciones`
--
ALTER TABLE `producto_variaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `colores`
--
ALTER TABLE `colores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `extras`
--
ALTER TABLE `extras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `mensajes_contacto`
--
ALTER TABLE `mensajes_contacto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de la tabla `producto_imagenes`
--
ALTER TABLE `producto_imagenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `producto_variaciones`
--
ALTER TABLE `producto_variaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Filtros para la tabla `producto_colores`
--
ALTER TABLE `producto_colores`
  ADD CONSTRAINT `producto_colores_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `producto_colores_ibfk_2` FOREIGN KEY (`color_id`) REFERENCES `colores` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `producto_extras`
--
ALTER TABLE `producto_extras`
  ADD CONSTRAINT `producto_extras_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `producto_extras_ibfk_2` FOREIGN KEY (`extra_id`) REFERENCES `extras` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `producto_imagenes`
--
ALTER TABLE `producto_imagenes`
  ADD CONSTRAINT `producto_imagenes_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `producto_variaciones`
--
ALTER TABLE `producto_variaciones`
  ADD CONSTRAINT `producto_variaciones_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
