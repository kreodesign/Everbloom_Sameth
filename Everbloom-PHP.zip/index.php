<?php 
// 1. Cargar configuración y la clase Router
require_once 'config/db.php'; 
require_once 'router.php';

// 2. Definir el mapa de rutas (Ruta en URL => Archivo en la carpeta views)
$mapaRutas = [
    ''          => ['view' => 'home.php'],
    'home'      => ['view' => 'home.php'],
    'producto'  => ['view' => 'producto.php'],
    'catalogo'  => ['view' => 'catalogo.php'],
    'contacto'  => ['view' => 'contacto.php'],
    'nosotros' => ['view' => 'nosotros.php'],

    'politicas-de-privacidad' => ['view' => 'privacidad.php'],
    'terminos-y-condiciones' => ['view' => 'terminos.php'],
    'politica-de-cookies' => ['view' => 'cookies.php'],
    'por-que-everbloom' => ['view' => 'porque-everbloom.php'],
    'preguntas-frecuentes' => ['view' => 'faq.php'],
    
    // Rutas de Autenticación
    'login'     => ['view' => 'login.php'],
    'auth'      => ['controller' => 'AuthController', 'method' => 'login'], // El envío del form
    'logout'    => ['controller' => 'AuthController', 'method' => 'logout'],

    // Rutas Protegidas (Solo entras si estás logueado)
    'admin/dashboard' => [
        'controller' => 'AdminController', 
        'method'     => 'index', 
        'auth'       => true
    ],
    'admin/mensajes' => [
        'controller' => 'AdminController', 
        'method'     => 'mensajes', 
        'auth'       => true
    ]
];

$router = new Router();

// 3. Pasamos el mapa de rutas y la conexión a la base de datos
$router->definir($mapaRutas, $pdo); 

// 4. Ejecutar la lógica de enrutamiento
$router->ejecutar();

?>